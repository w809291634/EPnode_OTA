#ifndef _FINSH_EX_H_
#define _FINSH_EX_H_

#define FIRMWARE_VER "V2.0.220331"

#include "bsp_flash/flash.h"

#endif