#ifndef __BOARD_H_
#define __BOARD_H_
#include "stm32f10x.h"
#include <rtthread.h>

void rt_hw_udelay(rt_uint32_t us);


#endif
