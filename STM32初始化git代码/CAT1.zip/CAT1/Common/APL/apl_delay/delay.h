#ifndef __DELAY_H_
#define __DELAY_H_
#include <rtthread.h>
#include "board.h"

void delay_ms(unsigned short times);
void delay_us(unsigned short times);

#endif
