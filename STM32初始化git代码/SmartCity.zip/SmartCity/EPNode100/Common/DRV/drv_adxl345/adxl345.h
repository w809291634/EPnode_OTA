/****************************************Copyright (c)**************************************************
**                               Guangzou ZLG-MCU Development Co.,LTD.
**                                      graduate school
**                                 http://www.zlgmcu.com
**
**--------------File Info-------------------------------------------------------------------------------
** File name:			FallDetect.h
** Descriptions:	���ٶȴ����������� 
**
**------------------------------------------------------------------------------------------------------
** Created by:			���ĳ�
** Created date:		2016-04-23
** Version:					1.0
** Descriptions:		The original version
**
**------------------------------------------------------------------------------------------------------
** Modified by:			
** Modified date:	
** Version:
** Descriptions:		
********************************************************************************************************/
#ifndef __FALLDETECT_H__
#define __FALLDETECT_H__

#include "stm32f4xx.h"

#define ADXL345_CS_PIN          GPIO_Pin_12
#define ADXL345_CS_PORT         GPIOB
#define ADXL345_CS_CLK          RCC_AHB1Periph_GPIOB

/* ADXL345 Register Map */
#define	ADXL345_DEVID			0x00 // R   Device ID.
#define ADXL345_THRESH_TAP		0x1D // R/W Tap threshold.
#define ADXL345_OFSX			0x1E // R/W X-axis offset.
#define ADXL345_OFSY			0x1F // R/W Y-axis offset.
#define ADXL345_OFSZ			0x20 // R/W Z-axis offset.
#define ADXL345_DUR				0x21 // R/W Tap duration.
#define ADXL345_LATENT			0x22 // R/W Tap latency.
#define ADXL345_WINDOW			0x23 // R/W Tap window.
#define ADXL345_THRESH_ACT		0x24 // R/W Activity threshold.
#define ADXL345_THRESH_INACT	0x25 // R/W Inactivity threshold.
#define ADXL345_TIME_INACT		0x26 // R/W Inactivity time.
#define ADXL345_ACT_INACT_CTL	0x27 // R/W Axis enable control for activity.
									 //     and inactivity detection.
#define ADXL345_THRESH_FF		0x28 // R/W Free-fall threshold.
#define ADXL345_TIME_FF			0x29 // R/W Free-fall time.
#define ADXL345_TAP_AXES		0x2A // R/W Axis control for tap/double tap.
#define ADXL345_ACT_TAP_STATUS	0x2B // R   Source of tap/double tap.
#define ADXL345_BW_RATE			0x2C // R/W Data rate and power mode control.
#define ADXL345_POWER_CTL		0x2D // R/W Power saving features control.
#define ADXL345_INT_ENABLE		0x2E // R/W Interrupt enable control.
#define ADXL345_INT_MAP			0x2F // R/W Interrupt mapping control.
#define ADXL345_INT_SOURCE		0x30 // R   Source of interrupts.
#define ADXL345_DATA_FORMAT		0x31 // R/W Data format control.
#define ADXL345_DATAX0			0x32 // R   X-Axis Data 0.
#define ADXL345_DATAX1			0x33 // R   X-Axis Data 1.
#define ADXL345_DATAY0			0x34 // R   Y-Axis Data 0.
#define ADXL345_DATAY1			0x35 // R   Y-Axis Data 1.
#define ADXL345_DATAZ0			0x36 // R   Z-Axis Data 0.
#define ADXL345_DATAZ1			0x37 // R   Z-Axis Data 1.
#define ADXL345_FIFO_CTL		0x38 // R/W FIFO control.
#define ADXL345_FIFO_STATUS		0x39 // R   FIFO status.

/* ADXL345_ACT_INACT_CTL Bits */
#define ADXL345_ACT_ACDC		(1 << 7)
#define ADXL345_ACT_X_EN		(1 << 6)
#define ADXL345_ACT_Y_EN		(1 << 5)
#define ADXL345_ACT_Z_EN		(1 << 4)
#define ADXL345_INACT_ACDC		(1 << 3)
#define ADXL345_INACT_X_EN		(1 << 2)
#define ADXL345_INACT_Y_EN		(1 << 1)
#define ADXL345_INACT_Z_EN		(1 << 0)

/* ADXL345_TAP_AXES Bits */
#define ADXL345_SUPPRESS		(1 << 3)
#define ADXL345_TAP_X_EN		(1 << 2)
#define ADXL345_TAP_Y_EN		(1 << 1)
#define ADXL345_TAP_Z_EN		(1 << 0)

/* ADXL345_ACT_TAP_STATUS Bits */
#define ADXL345_ACT_X_SRC		(1 << 6)
#define ADXL345_ACT_Y_SRC		(1 << 5)
#define ADXL345_ACT_Z_SRC		(1 << 4)
#define ADXL345_ASLEEP			(1 << 3)
#define ADXL345_TAP_X_SRC		(1 << 2)
#define ADXL345_TAP_Y_SRC		(1 << 1)
#define ADXL345_TAP_Z_SRC		(1 << 0)

/* ADXL345_BW_RATE Bits */
#define ADXL345_LOW_POWER		(1 << 4)
#define ADXL345_RATE(x)			((x) & 0xF)

/* ADXL345_POWER_CTL Bits */
#define ADXL345_PCTL_LINK       (1 << 5)
#define ADXL345_PCTL_AUTO_SLEEP (1 << 4)
#define ADXL345_PCTL_MEASURE    (1 << 3)
#define ADXL345_PCTL_SLEEP      (1 << 2)
#define ADXL345_PCTL_WAKEUP(x)  ((x) & 0x3)

/* ADXL345_INT_ENABLE / ADXL345_INT_MAP / ADXL345_INT_SOURCE Bits */
#define ADXL345_DATA_READY      (1 << 7)
#define ADXL345_SINGLE_TAP      (1 << 6)
#define ADXL345_DOUBLE_TAP      (1 << 5)
#define ADXL345_ACTIVITY        (1 << 4)
#define ADXL345_INACTIVITY      (1 << 3)
#define ADXL345_FREE_FALL       (1 << 2)
#define ADXL345_WATERMARK       (1 << 1)
#define ADXL345_OVERRUN         (1 << 0)

/* ADXL345_DATA_FORMAT Bits */
#define ADXL345_SELF_TEST       (1 << 7)
#define ADXL345_SPI             (1 << 6)
#define ADXL345_INT_INVERT      (1 << 5)
#define ADXL345_FULL_RES        (1 << 3)
#define ADXL345_JUSTIFY         (1 << 2)
#define ADXL345_RANGE(x)        ((x) & 0x3)
#define ADXL345_RANGE_PM_2G     0
#define ADXL345_RANGE_PM_4G     1
#define ADXL345_RANGE_PM_8G     2
#define ADXL345_RANGE_PM_16G    3

/* ADXL345_FIFO_CTL Bits */
#define ADXL345_FIFO_MODE(x)    (((x) & 0x3) << 6)
#define ADXL345_FIFO_BYPASS     0
#define ADXL345_FIFO_FIFO       1
#define ADXL345_FIFO_STREAM     2
#define ADXL345_FIFO_TRIGGER    3
#define ADXL345_TRIGGER         (1 << 5)
#define ADXL345_SAMPLES(x)      ((x) & 0x1F)

/* ADXL345_FIFO_STATUS Bits */
#define ADXL345_FIFO_TRIG       (1 << 7)
#define ADXL345_ENTRIES(x)      ((x) & 0x3F)

/* ADXL345 ID */
#define ADXL345_ID				0xE5


typedef struct{
  int xdata;
  int ydata;
  int zdata;
}ADXL345_Data;
/*********************************************************************************************************
** ��������: void ADXL345_Init(void)
** ��������: ADXL345  ��ʼ��
** �䡡��: ��
** �䡡��: ��
** ȫ�ֱ���: ��
** ����ģ��: app.c
**
** ������: ���ĳ�
** �ա���: 2016��4��23��
**-------------------------------------------------------------------------------------------------------
** �޸���:
** �ա���:
** ���⣺�����ϵ��������ж�
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
void ADXL345_Init(void);
/*********************************************************************************************************
** ��������: ADXL345_Read
** ��������: ADXL345  ��ȡ
** �䡡��: addr:�Ĵ�����ַ
**         Buf:��ȡ�����ַ
**         len:��ȡ���ݳ���
** �䡡��: ��
** ȫ�ֱ���: ��
** ����ģ��: FallDetect.c
**
** ������: ���ĳ�
** �ա���: 2016��4��23��
**-------------------------------------------------------------------------------------------------------
** �޸���:
** �ա���:
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
void ADXL345_Read(unsigned char addr,unsigned char buf[],unsigned len);
/*********************************************************************************************************
** ��������: ADXL345_Read_REG
** ��������: ADXL345  ��ȡ
** �䡡��: addr:�Ĵ�����ַ
** �䡡��: ��ȡ������
** ȫ�ֱ���: ��
** ����ģ��: FallDetect.c
**
** ������: ���ĳ�
** �ա���: 2016��4��23��
**-------------------------------------------------------------------------------------------------------
** �޸���:
** �ա���:
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
unsigned char ADXL345_Read_REG(unsigned char addr);
/*********************************************************************************************************
** ��������: ADXL345_Write_REG
** ��������: ADXL345  д��
** �䡡��: addr:�Ĵ�����ַ
**         dat: ��д������
** �䡡��: ��
** ȫ�ֱ���: ��
** ����ģ��: FallDetect.c
**
** ������: ���ĳ�
** �ա���: 2016��4��23��
**-------------------------------------------------------------------------------------------------------
** �޸���:
** �ա���:
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
void ADXL345_Write_REG(unsigned char addr,unsigned dat);
/*********************************************************************************************************
** ��������: ADXL345_GetValue
** ��������: ���ٶ�ֵ��ȡ
** �䡡��: ��
** �䡡��: ��
** ȫ�ֱ���: ��
** ����ģ��: FallDetect.c
**
** ������: ���ĳ�
** �ա���: 2016��4��23��
**-------------------------------------------------------------------------------------------------------
** �޸���:
** �ա���:
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
void ADXL345_GetValue(int16_t abuf[]);

#endif