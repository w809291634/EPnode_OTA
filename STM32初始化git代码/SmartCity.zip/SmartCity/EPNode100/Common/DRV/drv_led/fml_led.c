#include "fml_led.h"

void led_Init(void) {
  GPIO_InitTypeDef GPIO_InitStruct;
  RCC_AHB1PeriphClockCmd(LED_RUN_CLK | LED_NET_CLK | LED_DAT_CLK, ENABLE);
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Low_Speed;
  
  GPIO_InitStruct.GPIO_Pin = LED_RUN_PIN;
  GPIO_Init(LED_RUN_GPIO, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = LED_NET_PIN;
  GPIO_Init(LED_NET_GPIO, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = LED_DAT_PIN;
  GPIO_Init(LED_DAT_GPIO, &GPIO_InitStruct);
  led_off(LED_RUN);
  led_off(LED_NET);
  led_off(LED_DAT);
}

void led_on(e_LED led) {
  switch(led) {
    case LED_RUN: GPIO_ResetBits(LED_RUN_GPIO, LED_RUN_PIN); break;
    case LED_NET: GPIO_ResetBits(LED_NET_GPIO, LED_NET_PIN); break;
    case LED_DAT: GPIO_ResetBits(LED_DAT_GPIO, LED_DAT_PIN); break;
  }
}

void led_off(e_LED led) {
  switch(led) {
    case LED_RUN: GPIO_SetBits(LED_RUN_GPIO, LED_RUN_PIN); break;
    case LED_NET: GPIO_SetBits(LED_NET_GPIO, LED_NET_PIN); break;
    case LED_DAT: GPIO_SetBits(LED_DAT_GPIO, LED_DAT_PIN); break;
  }
}

void led_toggle(e_LED led) {
  switch(led) {
    case LED_RUN: GPIO_ToggleBits(LED_RUN_GPIO, LED_RUN_PIN); break;
    case LED_NET: GPIO_ToggleBits(LED_NET_GPIO, LED_NET_PIN); break;
    case LED_DAT: GPIO_ToggleBits(LED_DAT_GPIO, LED_DAT_PIN); break;
  }
}
