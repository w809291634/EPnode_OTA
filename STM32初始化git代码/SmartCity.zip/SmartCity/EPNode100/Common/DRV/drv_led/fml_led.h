#ifndef _FML_LED_H_
#define _FML_LED_H_
#include "stm32f4xx.h"

#define LED_RUN_CLK     RCC_AHB1Periph_GPIOD
#define LED_RUN_GPIO    GPIOD
#define LED_RUN_PIN     GPIO_Pin_14

#define LED_NET_CLK     RCC_AHB1Periph_GPIOD
#define LED_NET_GPIO    GPIOD
#define LED_NET_PIN     GPIO_Pin_13

#define LED_DAT_CLK    RCC_AHB1Periph_GPIOD
#define LED_DAT_GPIO   GPIOD
#define LED_DAT_PIN    GPIO_Pin_12

typedef enum {
  LED_RUN=0, LED_NET, LED_DAT
} e_LED;

void led_on(e_LED led);
void led_off(e_LED led);
void led_toggle(e_LED led);
void led_Init(void);

#endif
