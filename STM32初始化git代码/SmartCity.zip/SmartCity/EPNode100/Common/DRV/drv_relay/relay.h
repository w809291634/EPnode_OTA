#ifndef _RELAY_H_
#define _RELAY_H_
#include "stm32f4xx.h"

#define RELAY_CH1_CLK     RCC_AHB1Periph_GPIOA
#define RELAY_CH1_GPIO    GPIOA
#define RELAY_CH1_PIN     GPIO_Pin_5

#define RELAY_CH2_CLK     RCC_AHB1Periph_GPIOA
#define RELAY_CH2_GPIO    GPIOA
#define RELAY_CH2_PIN     GPIO_Pin_4

void relay_on(uint8_t ch);
void relay_off(uint8_t ch);
void relay_toggle(uint8_t ch);
void relay_Init(void);

#endif
