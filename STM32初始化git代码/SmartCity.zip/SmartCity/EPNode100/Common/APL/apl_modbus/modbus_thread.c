#include <rtthread.h>
#include "modbus_thread.h"
#include "user_mb_app_m.h"

static struct rt_thread modbus_thread;      /* �߳̽ṹ�� */
ALIGN(8) static rt_uint8_t modbus_stack[RT_MODBUS_THREAD_STACK_SIZE]; /* �߳�ջ */
static void modbus_thread_entry(void *parameter); /* �߳���ں��� */

char *modbus_err_string[7] = {
  "no error.",
  "illegal register address.",
  "illegal argument.",
  "receive data error.",
  "timeout error occurred.",
  "master is busy now.",
  "execute function error."
};

static void modbus_thread_entry(void *parameter) {
  Modbus_Master_task();
}

void modbus_thread_init(void) {
  rt_err_t result;
  result = rt_thread_init(&modbus_thread, "modbus task", modbus_thread_entry, RT_NULL,
                          modbus_stack, sizeof(modbus_stack), RT_MODBUS_THREAD_PRIORITY, RT_MODBUS_THREAD_TICK);
  if(result == RT_EOK) {
    Modbus_Master_init();
    result = rt_thread_startup(&modbus_thread);
    if(result != RT_EOK) {
      rt_kprintf("Error: modbus thread started failed!\n");
    }
  } else {
    rt_kprintf("Error: modbus thread create failed!\n");
  }
}
