/*
 * FreeModbus Libary: RT-Thread Port
 * Copyright (C) 2013 Armink <armink.ztl@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: porttimer_m.c,v 1.60 2013/08/13 15:07:05 Armink add Master Functions$
 */

/* ----------------------- Platform includes --------------------------------*/
#include "master_port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "master_mb_m.h"
#include "master_mbport.h"
#include <rtthread.h>
/* ----------------------- Defines ------------------------------------------*/
#define MB_TIMER_DEV            (TIM5)
#define MB_TIMER_CLK            (RCC_APB1Periph_TIM5)
#define MB_TIMER_CLK_OPT        (RCC_APB1PeriphClockCmd)
#define MB_TIMER_IRQ_CH         (TIM5_IRQn)
#define MB_TIMER_INT_ISR        (TIM5_IRQHandler)

#if MB_MASTER_RTU_ENABLED > 0 || MB_MASTER_ASCII_ENABLED > 0
/* ----------------------- Variables ----------------------------------------*/
static USHORT usT35TimeOut50us;
/* ----------------------- static functions ---------------------------------*/
static void prvvTIMERExpiredISR(void);
/* ----------------------- Start implementation -----------------------------*/
BOOL xMBMasterPortTimersInit(USHORT usTimeOut50us)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  usT35TimeOut50us = usTimeOut50us;
  TIM_Cmd(MB_TIMER_DEV,DISABLE);
  MB_TIMER_CLK_OPT(MB_TIMER_CLK,ENABLE);
  TIM_TimeBaseStructure.TIM_Period = usT35TimeOut50us-1;   //dly/50  us
  TIM_TimeBaseStructure.TIM_Prescaler = 4200-1;//84MHz/20kHz=4200
  TIM_TimeBaseStructure.TIM_ClockDivision=0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//?????
  TIM_TimeBaseInit(MB_TIMER_DEV,&TIM_TimeBaseStructure);
	
  TIM_ClearFlag(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,DISABLE);
  TIM_Cmd(MB_TIMER_DEV,ENABLE);
  
  NVIC_InitStructure.NVIC_IRQChannel = MB_TIMER_IRQ_CH;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  return TRUE;
}

//MB��ʱ���жϴ���
void MB_TIMER_INT_ISR(){
  prvvTIMERExpiredISR();
}

void vMBMasterPortTimersT35Enable()
{
    /* Set current timer mode, don't change it.*/
  vMBMasterSetCurTimerMode(MB_TMODE_T35);
  TIM_ClearITPendingBit(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,DISABLE);
  TIM_SetAutoreload(MB_TIMER_DEV,usT35TimeOut50us-1);
  TIM_GenerateEvent(MB_TIMER_DEV,TIM_EventSource_Update);
  TIM_ClearFlag(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,ENABLE);
  TIM_Cmd(MB_TIMER_DEV,ENABLE);	
}

void vMBMasterPortTimersConvertDelayEnable()
{
  /* Set current timer mode, don't change it.*/
  vMBMasterSetCurTimerMode(MB_TMODE_CONVERT_DELAY);
  TIM_ClearITPendingBit(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,DISABLE);
  TIM_SetAutoreload(MB_TIMER_DEV,MB_MASTER_DELAY_MS_CONVERT*20-1);
  TIM_GenerateEvent(MB_TIMER_DEV,TIM_EventSource_Update);
  TIM_ClearFlag(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,ENABLE);
  TIM_Cmd(MB_TIMER_DEV,ENABLE);	
}

void vMBMasterPortTimersRespondTimeoutEnable()
{
  /* Set current timer mode, don't change it.*/
  vMBMasterSetCurTimerMode(MB_TMODE_RESPOND_TIMEOUT);
  TIM_ClearITPendingBit(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,DISABLE);
  TIM_SetAutoreload(MB_TIMER_DEV,MB_MASTER_TIMEOUT_MS_RESPOND*20-1);
  TIM_GenerateEvent(MB_TIMER_DEV,TIM_EventSource_Update);
  TIM_ClearFlag(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,ENABLE);
  TIM_Cmd(MB_TIMER_DEV,ENABLE);	
}

void vMBMasterPortTimersDisable()
{
  TIM_ClearFlag(MB_TIMER_DEV,TIM_FLAG_Update);
  TIM_ITConfig(MB_TIMER_DEV,TIM_IT_Update,DISABLE);
//	TIM_Cmd(MB_TIMER_DEV,DISABLE);	
}

static void prvvTIMERExpiredISR(void)
{
  if( TIM_GetITStatus( MB_TIMER_DEV, TIM_IT_Update ) == SET){
    TIM_ClearITPendingBit(MB_TIMER_DEV,TIM_IT_Update);
    (void) pxMBMasterPortCBTimerExpired();
  }
}

#endif
