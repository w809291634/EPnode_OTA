#ifndef USER_MB_M_APP
#define USER_MB_M_APP
/* ----------------------- Modbus includes ----------------------------------*/
#include "master_mb_m.h"
#include "master_mbconfig.h"
#include "master_mbframe.h"
#include "master_mbutils.h"

/* -----------------------Slave Defines -------------------------------------*/
#define S_DISCRETE_INPUT_START        0
#define S_DISCRETE_INPUT_NDISCRETES   16
#define S_COIL_START                  0
#define S_COIL_NCOILS                 64
#define S_REG_INPUT_START             0
#define S_REG_INPUT_NREGS             100
#define S_REG_HOLDING_START           0
#define S_REG_HOLDING_NREGS           100
/* salve mode: holding register's all address */
#define          S_HD_RESERVE                     0
#define          S_HD_CPU_USAGE_MAJOR             1
#define          S_HD_CPU_USAGE_MINOR             2
/* salve mode: input register's all address */
#define          S_IN_RESERVE                     0
/* salve mode: coil's all address */
#define          S_CO_RESERVE                     0
/* salve mode: discrete's all address */
#define          S_DI_RESERVE                     0

/* -----------------------Master Defines -------------------------------------*/
#define M_DISCRETE_INPUT_START        0
#define M_DISCRETE_INPUT_NDISCRETES   16
#define M_COIL_START                  0
#define M_COIL_NCOILS                 64
#define M_REG_INPUT_START             0
#define M_REG_INPUT_NREGS             280
#define M_REG_HOLDING_START           0
#define M_REG_HOLDING_NREGS           100

#define RT_WAITING_100mS              100
#define RT_WAITING_200mS              200
#define RT_WAITING_300mS              300
/* master mode: holding register's all address */
#define          M_HD_RESERVE                     0
/* master mode: input register's all address */
#define          M_IN_RESERVE                     0
/* master mode: coil's all address */
#define          M_CO_RESERVE                     0
/* master mode: discrete's all address */
#define          M_DI_RESERVE                     0

#define MB_INVERTER_ID													( 1 )

#if M_DISCRETE_INPUT_NDISCRETES%8
  extern UCHAR ucMDiscInBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_DISCRETE_INPUT_NDISCRETES/8+1];
#else
  extern UCHAR ucMDiscInBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_DISCRETE_INPUT_NDISCRETES/8];
#endif
#if M_COIL_NCOILS%8
  extern UCHAR  ucMCoilBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_COIL_NCOILS/8+1];
#else
  extern UCHAR  ucMCoilBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_COIL_NCOILS/8];
#endif
extern USHORT usMRegInBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_REG_INPUT_NREGS];
extern USHORT usMRegHoldBuf[MB_MASTER_TOTAL_SLAVE_NUM][M_REG_HOLDING_NREGS];

void Modbus_Master_init(void);
void Modbus_Master_task(void);
//************************ *****************************************
//��������: void Modbus_Master_Send(void)
//��ڲ�������
//���ڲ�������
//��    ע��Editor��hwc   2013-07-3    Company: dfmc
//******************************************************************
eMBMasterReqErrCode Modbus_Master_Send(UCHAR cmd,UCHAR Daddr,USHORT RegAddr,USHORT *pRegAddr,USHORT NReg);

#endif
