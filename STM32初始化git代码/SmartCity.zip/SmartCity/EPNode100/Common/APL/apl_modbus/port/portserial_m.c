/*
 * FreeModbus Libary: STR71x Port
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: portserial.c,v 1.6 2006/06/15 15:41:20 wolti Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include "assert.h"

/* ----------------------- RTOS includes --------------------------------*/
#include <rtthread.h>
/* ----------------------- Platform includes --------------------------------*/
#include "master_port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "master_mb_m.h"
#include "master_mbport.h"

/* ----------------------- Defines ------------------------------------------*/
#define MB_UART_DEV             ( USART2 )
#define MB_UART_RX_PORT         ( GPIOA )
#define MB_UART_RX_PIN          ( GPIO_Pin_3 )
#define MB_UART_TX_PORT         ( GPIOA )
#define MB_UART_TX_PIN          ( GPIO_Pin_2 )
#define MB_UART_IRQ_CH          ( USART2_IRQn )
#define MB_UART_PERIPH_PORT     (RCC_AHB1Periph_GPIOA)
#define MB_UART_PERIPH          (RCC_APB1Periph_USART2)
#define MB_UART_TX_PINSource    (GPIO_PinSource2)
#define MB_UART_RX_PINSource    (GPIO_PinSource3)
#define MB_UART_AF              (GPIO_AF_USART2)
#define MB_INT_ISR              (USART2_IRQHandler)
#define MB_485EN_PORT           ( GPIOA )
#define MB_485EN_PIN            ( GPIO_Pin_6 )
#define MB_485CTL_PERIPH_PORT   (RCC_AHB1Periph_GPIOA)

static void prvvMBSerialIRQHandler( void )
{
  if(USART_GetITStatus(MB_UART_DEV,USART_IT_TC) == SET) {
    pxMBMasterFrameCBTransmitterEmpty();
    USART_ClearITPendingBit(MB_UART_DEV,USART_IT_TC);
  }
  if(USART_GetITStatus(MB_UART_DEV,USART_IT_RXNE) == SET) {
    pxMBMasterFrameCBByteReceived();
    USART_ClearITPendingBit(MB_UART_DEV,USART_IT_RXNE);
  }
  if(USART_GetITStatus(MB_UART_DEV,USART_IT_TXE) == SET){
    USART_ITConfig( MB_UART_DEV, USART_IT_TXE, DISABLE );
    pxMBMasterFrameCBTransmitterEmpty();
    if(SET==USART_GetFlagStatus(MB_UART_DEV,USART_FLAG_TC))
      USART_ClearFlag(MB_UART_DEV,USART_FLAG_TC);
    USART_ITConfig( MB_UART_DEV, USART_IT_TC, ENABLE );
  }
}

BOOL
xMBMasterPortSerialInit( UCHAR ucPort, ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity )
{
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  (void)ucPort;

  RCC_AHB1PeriphClockCmd(MB_UART_PERIPH_PORT,ENABLE);                         
  RCC_APB1PeriphClockCmd(MB_UART_PERIPH, ENABLE);                         

  GPIO_PinAFConfig(MB_UART_TX_PORT,MB_UART_TX_PINSource,MB_UART_AF);                     
  GPIO_PinAFConfig(MB_UART_RX_PORT,MB_UART_RX_PINSource,MB_UART_AF); 

  GPIO_InitStructure.GPIO_Pin=MB_UART_TX_PIN;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;                               
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;                                     
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;                           
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;                             
  GPIO_Init(MB_UART_TX_PORT,&GPIO_InitStructure); 

  GPIO_InitStructure.GPIO_Pin=MB_UART_RX_PIN;                                         
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;                                     
  GPIO_Init(MB_UART_RX_PORT,&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin= MB_485EN_PIN;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_OUT;
  GPIO_Init(MB_485EN_PORT,&GPIO_InitStructure);
  GPIO_ResetBits(MB_485EN_PORT, MB_485EN_PIN);  				//Only Tx enable    for Bluetooth use

  USART_DeInit(MB_UART_DEV);
    
  switch(ucDataBits){
    case 8:
      USART_InitStructure.USART_WordLength = USART_WordLength_8b;
      break;
    case 9:
      USART_InitStructure.USART_WordLength = USART_WordLength_9b;
      break;
    default:
      USART_InitStructure.USART_WordLength = USART_WordLength_8b;
      break;
  }
  USART_InitStructure.USART_BaudRate=ulBaudRate;                                     
  USART_InitStructure.USART_Parity = USART_Parity_No;                                                 
  USART_InitStructure.USART_StopBits = USART_StopBits_1;                           
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; 
  USART_InitStructure.USART_Mode=USART_Mode_Rx|USART_Mode_Tx; 
  USART_Init(MB_UART_DEV, &USART_InitStructure);       
  USART_Cmd(MB_UART_DEV,ENABLE);   
    
  NVIC_InitStructure.NVIC_IRQChannel = MB_UART_IRQ_CH;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  return TRUE;
}

//MB�����жϴ���
void MB_INT_ISR(){
  prvvMBSerialIRQHandler();
}

void
vMBMasterPortSerialEnable( BOOL xRxEnable, BOOL xTxEnable )
{
  if( xRxEnable ){
    GPIO_ResetBits(MB_485EN_PORT, MB_485EN_PIN);
    if(SET == USART_GetFlagStatus(MB_UART_DEV,USART_FLAG_RXNE))
      USART_ClearFlag(MB_UART_DEV,USART_FLAG_RXNE);
    USART_ITConfig( MB_UART_DEV, USART_IT_RXNE, ENABLE );
  } else{
    GPIO_SetBits(MB_485EN_PORT, MB_485EN_PIN);
    USART_ITConfig( MB_UART_DEV, USART_IT_RXNE, DISABLE );
  }

  if( xTxEnable ){
    GPIO_SetBits(MB_485EN_PORT, MB_485EN_PIN);
    // if(SET == USART_GetFlagStatus(MB_UART_DEV,USART_FLAG_TXE))
    //   USART_ClearFlag(MB_UART_DEV,USART_FLAG_TXE);
    USART_ITConfig( MB_UART_DEV, USART_IT_TXE, ENABLE );
  }
  else{
    GPIO_ResetBits(MB_485EN_PORT, MB_485EN_PIN);
    if(SET == USART_GetFlagStatus(MB_UART_DEV,USART_FLAG_TC))
      USART_ClearFlag(MB_UART_DEV,USART_FLAG_TC);
    USART_ITConfig( MB_UART_DEV, USART_IT_TC, DISABLE );
  }
}

BOOL
xMBMasterPortSerialPutByte( CHAR ucByte )
{
  MB_UART_DEV->DR = ucByte;
  return TRUE;
}

BOOL
xMBMasterPortSerialGetByte( CHAR * pucByte )
{
  *pucByte = MB_UART_DEV->DR;
  return TRUE;
}
