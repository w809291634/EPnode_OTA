#ifndef __RF_IF2_APP_H__
#define __RF_IF2_APP_H__

#include "stm32f4xx.h"

typedef enum {
  RF_IF2_NULL=0, RF_IF2_LTE
} e_rf_if2_dev;

extern e_rf_if2_dev rf_if2_dev;
extern char rf_if2_imei[20];

void rf_if2_run(void);
void rf_if2_init(void);
int16_t rf_if2_send(uint8_t *pdata, uint16_t length, uint16_t timeout_ms);
void rf_if2_Link(void);

#endif  //__RF_IF2_APP_H__
