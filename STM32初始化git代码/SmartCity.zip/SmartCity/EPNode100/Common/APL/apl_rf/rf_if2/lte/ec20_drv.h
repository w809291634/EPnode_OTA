#ifndef __EC20_DRV_H__
#define __EC20_DRV_H__

void ec20_Get_IMEI(char *pimei);
void ec20_disconnect(void);
int8_t ec20_TCP_Connect(char *ip, uint16_t port);

#endif