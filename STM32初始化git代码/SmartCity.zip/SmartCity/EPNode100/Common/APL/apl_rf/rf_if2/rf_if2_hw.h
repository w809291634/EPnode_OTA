#ifndef __RF_IF2_HW_H__
#define __RF_IF2_HW_H__

#include "stm32f4xx.h"

//���ݻ���������
#define RF_IF2_RINGBUF_SIZE 1024

//����IO
#define RF_IF2_TX_CLK       RCC_AHB1Periph_GPIOC
#define RF_IF2_TX_PORT      GPIOC
#define RF_IF2_TX_PIN       GPIO_Pin_12
#define RF_IF2_TX_AF        GPIO_AF_UART5
#define RF_IF2_TX_SOURCE    GPIO_PinSource12
#define RF_IF2_RX_CLK       RCC_AHB1Periph_GPIOD
#define RF_IF2_RX_PORT      GPIOD
#define RF_IF2_RX_PIN       GPIO_Pin_2
#define RF_IF2_RX_AF        GPIO_AF_UART5
#define RF_IF2_RX_SOURCE    GPIO_PinSource2
//�����豸
#define RF_IF2_UART         UART5
#define RF_IF2_UART_CLK     RCC_APB1Periph_UART5
#define RF_IF2_UART_CLKInit RCC_APB1PeriphClockCmd
#define RF_IF2_UART_IRQn    UART5_IRQn
#define RF_IF2_UART_ISR     UART5_IRQHandler
//����DMA����
#define RF_IF2_DMA_CLK      RCC_AHB1Periph_DMA1
#define RF_IF2_DMA_STREAM   DMA1_Stream0
#define RF_IF2_DMA_CHANNEL  DMA_Channel_4

extern struct rt_mutex rf_if2_uart_mutex;
extern struct rt_mailbox rf_if2_data_mb;

void rf_if2_NetStatus(FlagStatus Status);
void rf_if2_uart_send(uint8_t *pdata, uint16_t length);
void rf_if2_uart_flush(uint16_t timeout_ms);
int16_t rf_if2_uart_read(uint8_t *pdata, uint16_t length, uint16_t timeout_ms);
void rf_if2_HW_Init(void);
void rf_if2_uart_speed(uint32_t baudrate);

#endif  //__RF_IF2_HW_H__
