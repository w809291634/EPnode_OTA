#ifndef __NB_DRV_H__
#define __NB_DRV_H__

typedef struct {
  char node_id[20];
  char mode[8];
  char sip[20];
  char aid[40];
  char akey[100];
} t_nb_info;

extern t_nb_info nb_info;

int8_t nb_set_handle(uint8_t index, char* pstr);
void nb_Get_Info(void);

#endif