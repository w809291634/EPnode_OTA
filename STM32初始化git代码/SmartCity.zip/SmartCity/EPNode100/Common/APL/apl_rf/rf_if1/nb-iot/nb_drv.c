#include <rtthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "rf_if1_hw.h"
#include "nb_drv.h"

t_nb_info nb_info;

typedef struct {
  char set_cmd[16];
  char query_cmd[16];
  char reply[10];
  uint16_t reply_len;
} t_nb_cmd;
static t_nb_cmd nb_cmd[5] = {
  {"","AT+NODEID?\r\n","+NODEID:", 8},
  {"AT+MODE=",  "AT+MODE?\r\n", "+MODE:", 6},
  {"AT+SIP=",   "AT+SIP?\r\n",  "+SIP:", 5},
  {"AT+AID=",   "AT+AID?\r\n",  "+AID:", 5},
  {"AT+AKEY=",  "AT+AKEY?\r\n", "+AKEY:\"", 7}
};

int8_t nb_set_handle(uint8_t index, char* pstr) {
  uint16_t len;
  int8_t res = -1;
  char recv[41];
  char cmd[110];
  
  switch(index) {
    case 1: strcpy(nb_info.mode, pstr); break;
    case 2: strcpy(nb_info.sip, pstr); break;
    case 3: strcpy(nb_info.aid, pstr); break;
    case 4: strcpy(nb_info.akey, pstr); break;
    case 5: break;
    default: return res;
  }
  
  if(index == 5) {
    strcpy(cmd, "AT+ENVSAVE\r\n");
  } else if(index == 4) {
    sprintf(cmd, "%s\"%s\"\r\n", nb_cmd[index].set_cmd, pstr);
  } else {
    sprintf(cmd, "%s%s\r\n", nb_cmd[index].set_cmd, pstr);
  }
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 40, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  return res;
}

static void nb_query_handle(uint8_t index) {
  if(index > 4) return;
  
  uint16_t len;
  char recv[101];
  char *phead = NULL, *ptail = NULL;
  
  rf_if1_uart_send((uint8_t*)nb_cmd[index].query_cmd, strlen(nb_cmd[index].query_cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 100, 50);
  if(len > nb_cmd[index].reply_len) {
    recv[len] = 0;
    phead = strstr((const char*)recv, nb_cmd[index].reply);
    if(phead != NULL) {
      if(index == 4) {
        ptail = strstr((const char*)phead, "\"\r\n");
      } else {
        ptail = strstr((const char*)phead, "\r\n");
      }
      if(ptail != NULL) *ptail = 0;
      else return;
      
      switch(index) {
        case 0: strcpy(nb_info.node_id, phead+nb_cmd[index].reply_len); break;
        case 1: strcpy(nb_info.mode, phead+nb_cmd[index].reply_len); break;
        case 2: strcpy(nb_info.sip, phead+nb_cmd[index].reply_len); break;
        case 3: strcpy(nb_info.aid, phead+nb_cmd[index].reply_len); break;
        case 4: strcpy(nb_info.akey, phead+nb_cmd[index].reply_len); break;
        default: break;
      }
    }
  }
}

void nb_Get_Info(void) {
  for(uint8_t i = 1; i < 5; i++) {
    nb_query_handle(i);
  }
  while(nb_info.node_id[0] == 0) {
    rt_thread_mdelay(3000);
    nb_query_handle(0);
  }
  rf_if1_uart_flush(50);
}
