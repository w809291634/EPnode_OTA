#include <rtthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "rf_if1_hw.h"
#include "lora_drv.h"

t_lora_info lora_info;

typedef struct {
  char set_cmd[16];
  char query_cmd[16];
  char reply[10];
  uint16_t reply_len;
} t_lora_cmd;
static t_lora_cmd lora_cmd[10] = {
  {"","AT+NODEID?\r\n","+NODEID:", 8},
  {"AT+NETID=", "AT+NETID?\r\n", "+NETID:", 7},
  {"AT+FP=",    "AT+FP?\r\n",    "+FP:", 4},
  {"AT+PV=",    "AT+PV?\r\n",    "+PV:", 4},
  {"AT+SF=",    "AT+SF?\r\n",    "+SF:", 4},
  {"AT+CR=",    "AT+CR?\r\n",    "+CR:", 4},
  {"AT+PS=",    "AT+PS?\r\n",    "+PS:", 4},
  {"AT+BW=",    "AT+BW?\r\n",    "+BW:", 4},
  {"AT+HOP=",   "AT+HOP?\r\n",   "+HOP:", 5},
  {"AT+HOPTAB=","AT+HOPTAB?\r\n","+HOPTAB:", 8}
};

int8_t lora_set_handle(uint8_t index, uint16_t value) {
  uint16_t len;
  int8_t res = -1;
  char recv[61];
  char cmd[60];
  
  switch(index) {
    case 1:
      if(value >= 0x01 && value <= 0xFE) {
        lora_info.net_id = value;
        res = 0;
      }
      break;
    case 2:
      if(value >= 420 && value <= 470) {
        lora_info.fp = value;
        res = 0;
      }
      break;
    case 3:
      if(value >= 1 && value <= 20) {
        lora_info.pv = value;
        res = 0;
      }
      break;
    case 4:
      if(value >= 6 && value <= 12) {
        lora_info.sf = value;
        res = 0;
      }
      break;
    case 5:
      if(value >= 1 && value <= 4) {
        lora_info.cr = value;
        res = 0;
      }
      break;
    case 6:
      if(value >= 4 && value <= 100) {
        lora_info.ps = value;
        res = 0;
      }
      break;
    case 7:
      if(value <= 9) {
        lora_info.bw = value;
        res = 0;
      }
      break;
    case 8:
      if(value <= 1) {
        lora_info.hop = value;
        res = 0;
      }
      break;
    case 9:
      res = 0;
      break;
    default: return res;
  }
  if(res == -1) return res;
  res = -1;
  
  if(index < 9) {
    sprintf(cmd, "%s%u\r\n", lora_cmd[index].set_cmd, value);
  } else if(index == 9) {
    strcpy(cmd, "AT+ENVSAVE\r\n");
  }
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 60, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  return res;
}

static void lora_query_handle(uint8_t index) {
  if(index > 9) return;
  
  uint16_t len;
  char recv[61];
  char *phead = NULL;
  
  rf_if1_uart_send((uint8_t*)lora_cmd[index].query_cmd, strlen(lora_cmd[index].query_cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 60, 50);
  if(len > lora_cmd[index].reply_len) {
    recv[len] = 0;
    phead = strstr((const char*)recv, lora_cmd[index].reply);
    if(phead != NULL) {
      uint16_t temp;
      if(index < 9) temp = strtol(phead+lora_cmd[index].reply_len, NULL, 0);
      switch(index) {
        case 0: lora_info.node_id = temp; break;
        case 1: lora_info.net_id = temp; break;
        case 2: lora_info.fp = temp; break;
        case 3: lora_info.pv = temp; break;
        case 4: lora_info.sf = temp; break;
        case 5: lora_info.cr = temp; break;
        case 6: lora_info.ps = temp; break;
        case 7: lora_info.bw = temp; break;
        case 8: lora_info.hop = temp; break;
        case 9: 
          strncpy(lora_info.hopTab, phead+lora_cmd[index].reply_len, 39);
          lora_info.hopTab[39] = 0;
          break;
        default: break;
      }
    }
  }
}

void lora_Get_Info(void) {
  for(uint8_t i = 0; i < 10; i++) {
    lora_query_handle(i);
  }
  rf_if1_uart_flush(50);
}
