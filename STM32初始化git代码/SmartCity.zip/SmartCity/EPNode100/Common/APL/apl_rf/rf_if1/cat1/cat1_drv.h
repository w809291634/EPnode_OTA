#ifndef __CAT1_DRV_H__
#define __CAT1_DRV_H__

typedef struct {
  char node_id[20];
  char sip[20];
  char aid[40];
  char akey[100];
} t_cat1_info;

extern t_cat1_info cat1_info;

int8_t cat1_set_handle(uint8_t index, char* pstr);
void cat1_Get_Info(void);

#endif