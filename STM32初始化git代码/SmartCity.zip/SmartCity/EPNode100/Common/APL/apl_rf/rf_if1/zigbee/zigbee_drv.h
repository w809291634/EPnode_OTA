#ifndef __ZIGBEE_DRV_H__
#define __ZIGBEE_DRV_H__

typedef struct {
  char mac[24];
  uint16_t panid;
  uint8_t channel;
  uint8_t type;
} t_zigbee_info;

extern t_zigbee_info zigbee_info;

int8_t zigbee_Set_Panid(uint16_t panid);
int8_t zigbee_Set_Channel(uint8_t channel);
int8_t zigbee_Set_Type(uint8_t type);
void zigbee_Get_Info(void);

#endif