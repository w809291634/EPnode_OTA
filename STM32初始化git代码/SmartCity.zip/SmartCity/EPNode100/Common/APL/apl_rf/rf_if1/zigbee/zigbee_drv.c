#include <rtthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "rf_if1_hw.h"
#include "zigbee_drv.h"

t_zigbee_info zigbee_info;

/* ����zigbeeͨѶPanid�����óɹ�������0������ʧ�ܣ�����-1 */
int8_t zigbee_Set_Panid(uint16_t panid) {
  uint16_t len;
  int8_t res = -1;
  char recv[51];
  char cmd[20];
  
  zigbee_info.panid = panid;
  sprintf(cmd, "AT+PANID=%u\r\n", zigbee_info.panid);
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  rf_if1_uart_flush(0);
  return res;
}

/* ����zigbeeͨѶ�ŵ������óɹ�������0������ʧ�ܣ�����-1 */
int8_t zigbee_Set_Channel(uint8_t channel) {
  uint16_t len;
  int8_t res = -1;
  char recv[51];
  char cmd[20];
  
  zigbee_info.channel = channel;
  sprintf(cmd, "AT+CHANNEL=%u\r\n", zigbee_info.channel);
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  rf_if1_uart_flush(0);
  return res;
}

/* ����zigbeeͨѶ���͡����óɹ�������0������ʧ�ܣ�����-1 */
int8_t zigbee_Set_Type(uint8_t type) {
  uint16_t len;
  int8_t res = -1;
  char recv[51];
  char cmd[20];
  
  zigbee_info.type = type;
  sprintf(cmd, "AT+LOGICALTYPE=%u\r\n", zigbee_info.type);
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  rf_if1_uart_flush(0);
  return res;
}

void zigbee_Get_Info(void) {
  uint16_t len;
  char recv[51];
  char *phead = NULL;
  
  //��ȡMAC��ַ
  rf_if1_uart_send((uint8_t*)"AT+MAC?\r\n", strlen("AT+MAC?\r\n"));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>=28) {
    recv[len] = 0;
    phead = strstr((const char*)recv, "+MAC");
    if(phead != NULL) {
      strncpy(zigbee_info.mac, phead+5, 23);
      zigbee_info.mac[23] = 0;
    }
  }
  //��ȡPANID
  rf_if1_uart_send((uint8_t*)"AT+PANID?\r\n", strlen("AT+PANID?\r\n"));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>7) {
    recv[len] = 0;
    phead = strstr((const char*)recv, "+PANID");
    if(phead != NULL) {
      zigbee_info.panid = strtol(phead+7, NULL, 0);
    }
  }
  //��ȡChannel
  rf_if1_uart_send((uint8_t*)"AT+CHANNEL?\r\n", strlen("AT+CHANNEL?\r\n"));
  len = rf_if1_uart_read((uint8_t*)recv, 50, 100);
  if(len>9) {
    recv[len] = 0;
    phead = strstr((const char*)recv, "+CHANNEL");
    if(phead != NULL) {
      zigbee_info.channel = strtol(phead+9, NULL, 0);
    }
  }
  //��ȡType
  rf_if1_uart_send((uint8_t*)"AT+LOGICALTYPE?\r\n", strlen("AT+LOGICALTYPE?\r\n"));
  len = rf_if1_uart_read((uint8_t *)recv, 50, 100);
  if(len>13) {
    recv[len] = 0;
    phead = strstr((const char*)recv, "+LOGICALTYPE");
    if(phead != NULL) {
      zigbee_info.type = strtol(phead+13, NULL, 0);
    }
  }
  rf_if1_uart_flush(50);
}
