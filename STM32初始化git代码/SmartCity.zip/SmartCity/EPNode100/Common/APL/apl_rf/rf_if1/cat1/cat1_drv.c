#include <rtthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "rf_if1_hw.h"
#include "cat1_drv.h"

t_cat1_info cat1_info;

typedef struct {
  char set_cmd[16];
  char query_cmd[16];
  char reply[10];
  uint16_t reply_len;
} t_cat1_cmd;
static t_cat1_cmd cat1_cmd[4] = {
  {"","AT+NODEID?\r\n","+NODEID:", 8},
  {"AT+SIP=",   "AT+SIP?\r\n",  "+SIP:", 5},
  {"AT+AID=",   "AT+AID?\r\n",  "+AID:", 5},
  {"AT+AKEY=",  "AT+AKEY?\r\n", "+AKEY:\"", 7}
};

int8_t cat1_set_handle(uint8_t index, char* pstr) {
  uint16_t len;
  int8_t res = -1;
  char recv[41];
  char cmd[110];
  
  switch(index) {
    case 1: strcpy(cat1_info.sip, pstr); break;
    case 2: strcpy(cat1_info.aid, pstr); break;
    case 3: strcpy(cat1_info.akey, pstr); break;
    case 4: break;
    default: return res;
  }
  
  if(index == 4) {
    strcpy(cmd, "AT+ENVSAVE\r\n");
  } else if(index == 3) {
    sprintf(cmd, "%s\"%s\"\r\n", cat1_cmd[index].set_cmd, pstr);
  } else {
    sprintf(cmd, "%s%s\r\n", cat1_cmd[index].set_cmd, pstr);
  }
  rf_if1_uart_send((uint8_t*)cmd, strlen(cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 40, 100);
  if(len>0) {
    recv[len] = 0;
    if(strstr((const char*)recv, "OK") != NULL) res = 0;
  }
  return res;
}

static void cat1_query_handle(uint8_t index) {
  if(index > 3) return;
  
  uint16_t len;
  char recv[101];
  char *phead = NULL, *ptail = NULL;
  
  rf_if1_uart_send((uint8_t*)cat1_cmd[index].query_cmd, strlen(cat1_cmd[index].query_cmd));
  len = rf_if1_uart_read((uint8_t*)recv, 100, 50);
  if(len > cat1_cmd[index].reply_len) {
    recv[len] = 0;
    phead = strstr((const char*)recv, cat1_cmd[index].reply);
    if(phead != NULL) {
      if(index == 3) {
        ptail = strstr((const char*)phead, "\"\r\n");
      } else {
        ptail = strstr((const char*)phead, "\r\n");
      }
      if(ptail != NULL) *ptail = 0;
      else return;
      
      switch(index) {
        case 0: strcpy(cat1_info.node_id, phead+cat1_cmd[index].reply_len); break;
        case 1: strcpy(cat1_info.sip, phead+cat1_cmd[index].reply_len); break;
        case 2: strcpy(cat1_info.aid, phead+cat1_cmd[index].reply_len); break;
        case 3: strcpy(cat1_info.akey, phead+cat1_cmd[index].reply_len); break;
        default: break;
      }
    }
  }
}

void cat1_Get_Info(void) {
  for(uint8_t i = 1; i < 4; i++) {
    cat1_query_handle(i);
  }
  while(cat1_info.node_id[0] == 0) {
    rt_thread_mdelay(3000);
    cat1_query_handle(0);
  }
  rf_if1_uart_flush(50);
}
