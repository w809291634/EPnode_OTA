#ifndef __RF_IF1_APP_H__
#define __RF_IF1_APP_H__

#include "stm32f4xx.h"

typedef enum {
  RF_IF1_NULL=0, RF_IF1_ZIGBEE, RF_IF1_LORA, RF_IF1_NB, RF_IF1_CAT1
} e_rf_if1_dev;

extern e_rf_if1_dev rf_if1_dev;

int rf_if1_get_rssi(void);
void rf_if1_run(void);
void rf_if1_init(void);
int16_t rf_if1_send(uint8_t *pdata, uint16_t length, uint16_t timeout_ms);
void rf_if1_Link(void);

#endif  //__RF_IF1_APP_H__
