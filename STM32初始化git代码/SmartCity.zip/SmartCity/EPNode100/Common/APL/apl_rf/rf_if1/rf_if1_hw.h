#ifndef __RF_IF1_HW_H__
#define __RF_IF1_HW_H__

#include "stm32f4xx.h"

//���ݻ���������
#define RF_IF1_RINGBUF_SIZE 1024

//����IO
#define RF_IF1_TX_CLK       RCC_AHB1Periph_GPIOB
#define RF_IF1_TX_PORT      GPIOB
#define RF_IF1_TX_PIN       GPIO_Pin_10
#define RF_IF1_TX_AF        GPIO_AF_USART3
#define RF_IF1_TX_SOURCE    GPIO_PinSource10
#define RF_IF1_RX_CLK       RCC_AHB1Periph_GPIOB
#define RF_IF1_RX_PORT      GPIOB
#define RF_IF1_RX_PIN       GPIO_Pin_11
#define RF_IF1_RX_AF        GPIO_AF_USART3
#define RF_IF1_RX_SOURCE    GPIO_PinSource11
//�����豸
#define RF_IF1_UART         USART3
#define RF_IF1_UART_CLK     RCC_APB1Periph_USART3
#define RF_IF1_UART_CLKInit RCC_APB1PeriphClockCmd
#define RF_IF1_UART_IRQn    USART3_IRQn
#define RF_IF1_UART_ISR     USART3_IRQHandler
//����DMA����
#define RF_IF1_DMA_CLK      RCC_AHB1Periph_DMA1
#define RF_IF1_DMA_STREAM   DMA1_Stream1
#define RF_IF1_DMA_CHANNEL  DMA_Channel_4

extern struct rt_mutex rf_if1_uart_mutex;
extern struct rt_mailbox rf_if1_data_mb;

void rf_if1_NetStatus(FlagStatus Status);
void rf_if1_uart_send(uint8_t *pdata, uint16_t length);
void rf_if1_uart_flush(uint16_t timeout_ms);
int16_t rf_if1_uart_read(uint8_t *pdata, uint16_t length, uint16_t timeout_ms);
void rf_if1_HW_Init(void);
void rf_if1_uart_speed(uint32_t baudrate);

#endif  //__RF_IF1_HW_H__
