/*********************************************************************************************
* �ļ���ADC.h
* ���ߣ�Cage 2019.1.12
* ˵����ADC+DMA����
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
#ifndef _SENSOR_AD_H_
#define _SENSOR_AD_H_

#include "stm32f4xx.h"

#define SENSOR_AD_NUM 2

#define AD_CH_GAS 0 /*������*/
#define AD_CH_CUR 1 /*4-20mA*/

//ADC����
#define SENSOR_ADC           ADC1
#define SENSOR_ADC_CLK       RCC_APB2Periph_ADC1
#define SENSOR_ADC_CLK_INIT  RCC_APB2PeriphClockCmd

#define ADC_GAS_PORT GPIOC
#define ADC_GAS_PIN  GPIO_Pin_1
#define ADC_GAS_CLK  RCC_AHB1Periph_GPIOC
#define ADC_GAS_CHANNEL  ADC_Channel_11

#define ADC_CUR_PORT GPIOC
#define ADC_CUR_PIN  GPIO_Pin_3
#define ADC_CUR_CLK  RCC_AHB1Periph_GPIOC
#define ADC_CUR_CHANNEL  ADC_Channel_13

//DMA����
#define SENSOR_DMA_STREAM  DMA2_Stream4
#define SENSOR_DMA_CHANNEL DMA_Channel_0

uint16_t ad_Get_Sensor_Value(uint8_t ad_ch);
void ad_Module_Init(void);

#endif  //_SENSOR_AD_H_
