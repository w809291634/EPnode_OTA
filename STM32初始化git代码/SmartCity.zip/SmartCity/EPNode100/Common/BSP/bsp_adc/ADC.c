/*********************************************************************************************
* �ļ���ADC.c
* ���ߣ�Cage 2019.1.12
* ˵����ADC+DMA����
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
#include "ADC.h"

#define AD_FILTER_N     50
#define AD_ABANDON_N    10
static uint16_t _s_Sensor_ADCValue[AD_FILTER_N][SENSOR_AD_NUM];

/*********************************************************************************************
* ���ƣ�ad_Get_Sensor_Value
* ���ܣ���ȡ����������
* ��������
* ���أ���
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
uint16_t ad_Get_Sensor_Value(uint8_t ad_ch) {
  if(ad_ch >= SENSOR_AD_NUM) return 0;
  
  //����AD_FILTER_N�β���ֵ������ʱ������
  uint16_t buf[AD_FILTER_N];
  for(uint16_t i = 0; i < AD_FILTER_N; i++) {
    buf[i] = _s_Sensor_ADCValue[i][ad_ch];
  }
  
  //ð�����򷨣�����AD_FILTER_N�β���ֵ��С��������
  uint16_t temp;
  for(uint16_t i = 0; i < AD_FILTER_N - 2; i++) {
    for(uint16_t j = 0; j < AD_FILTER_N - 1 - i; j++) {
      if(buf[j] > buf[j+1]) {
        temp = buf[j];
        buf[j] = buf[j+1];
        buf[j+1] = temp;
      }
    }
  }
  
  //ȥ��AD_ABANDON_N�����ֵ��AD_ABANDON_N����Сֵ�����м�ֵƽ��
  uint32_t sum = 0;
  for(uint16_t i = AD_ABANDON_N; i < AD_FILTER_N - AD_ABANDON_N; i++) {
    sum += buf[i];
  }
  
  return sum / (AD_FILTER_N-AD_ABANDON_N*2);
}


/*********************************************************************************************
* ���ƣ�_ad_DMA_Init
* ���ܣ�DMA��ʼ��
* ��������
* ���أ���
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
static void _ad_DMA_Init(void) {
  DMA_InitTypeDef DMA_InitStruct;    
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);

  DMA_DeInit(SENSOR_DMA_STREAM);
  DMA_InitStruct.DMA_Channel = SENSOR_DMA_CHANNEL; 
  DMA_InitStruct.DMA_Memory0BaseAddr = (uint32_t)&_s_Sensor_ADCValue;
  DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)&(SENSOR_ADC->DR);
  DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralToMemory;
  DMA_InitStruct.DMA_BufferSize = SENSOR_AD_NUM * AD_FILTER_N;
  DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStruct.DMA_Priority = DMA_Priority_Medium;
  DMA_InitStruct.DMA_FIFOMode = DMA_FIFOMode_Disable;      
  DMA_InitStruct.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
  DMA_InitStruct.DMA_MemoryBurst = DMA_MemoryBurst_Single;
  DMA_InitStruct.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_Init(SENSOR_DMA_STREAM, &DMA_InitStruct);
  
  DMA_Cmd(SENSOR_DMA_STREAM, ENABLE);
}

/*********************************************************************************************
* ���ƣ�_ad_GPIO_Init
* ���ܣ�GPIO��ʼ��
* ��������
* ���أ���
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
static void _ad_GPIO_Init(void) {
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd(ADC_GAS_CLK | ADC_CUR_CLK, ENABLE);
  
  GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Fast_Speed;
  
  GPIO_InitStructure.GPIO_Pin	= ADC_GAS_PIN;
  GPIO_Init(ADC_GAS_PORT, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin	= ADC_CUR_PIN;
  GPIO_Init(ADC_CUR_PORT, &GPIO_InitStructure);
}

/*********************************************************************************************
* ���ƣ�_ad_ADC_Init
* ���ܣ�ADC��ʼ��
* ��������
* ���أ���
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
static void _ad_ADC_Init(void) {
  ADC_CommonInitTypeDef ADC_CommonInitStruct;
  ADC_InitTypeDef ADC_InitStruct;
  
  ADC_CommonStructInit(&ADC_CommonInitStruct);//ADCʱ��Ƶ�ʣ�APB2/2=42MHz
  ADC_CommonInit(&ADC_CommonInitStruct);
  SENSOR_ADC_CLK_INIT(SENSOR_ADC_CLK, ENABLE);
  
  ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStruct.ADC_ScanConvMode = ENABLE;
  ADC_InitStruct.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStruct.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
  ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStruct.ADC_NbrOfConversion = SENSOR_AD_NUM;
  
  ADC_Init(SENSOR_ADC, &ADC_InitStruct);
  
  ADC_RegularChannelConfig(SENSOR_ADC, ADC_GAS_CHANNEL, 1, ADC_SampleTime_480Cycles);
  ADC_RegularChannelConfig(SENSOR_ADC, ADC_CUR_CHANNEL, 2, ADC_SampleTime_480Cycles);
  
  //����ADC-DMA
  ADC_DMARequestAfterLastTransferCmd(SENSOR_ADC, ENABLE);
  ADC_DMACmd(SENSOR_ADC, ENABLE);
  //����ADC
  ADC_Cmd(SENSOR_ADC, ENABLE);
  ADC_SoftwareStartConv(SENSOR_ADC);
}


/*********************************************************************************************
* ���ƣ�ad_Module_Init
* ���ܣ������ʼ��
* ��������
* ���أ���
* �޸ģ�
* ע�ͣ�
*********************************************************************************************/
void ad_Module_Init(void) {
  _ad_DMA_Init();
  _ad_GPIO_Init();
  _ad_ADC_Init();
}
