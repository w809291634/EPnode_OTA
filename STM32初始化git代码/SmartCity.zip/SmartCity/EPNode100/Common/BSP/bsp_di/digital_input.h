#ifndef __DIGITAL_INPUT_H__
#define __DIGITAL_INPUT_H__

#include "stm32f4xx.h"

/*********************************************************************************************
* �궨��
*********************************************************************************************/
#define DI_CH1_PIN      GPIO_Pin_1
#define DI_CH1_PORT     GPIOB
#define DI_CH1_CLK      RCC_AHB1Periph_GPIOB

#define DI_CH2_PIN      GPIO_Pin_5
#define DI_CH2_PORT     GPIOC
#define DI_CH2_CLK      RCC_AHB1Periph_GPIOC

#define DI_CH3_PIN      GPIO_Pin_4
#define DI_CH3_PORT     GPIOC
#define DI_CH3_CLK      RCC_AHB1Periph_GPIOC

/********************************************************************************************/

uint8_t di_GetStatus(void);
void di_Init(void);
#endif
