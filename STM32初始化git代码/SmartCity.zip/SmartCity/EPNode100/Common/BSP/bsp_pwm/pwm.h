#ifndef _pwm_h_
#define _pwm_h_

#include <stdio.h>
#include "stm32f4xx.h"

typedef enum {
  PWM1=1, PWM2
} e_pwm;

//PWM����
#define PWM1_FREQ   10000   /* PWM1Ƶ�ʣ�Hz�� */ 
#define PWM2_FREQ   50      /* PWM2Ƶ�ʣ�Hz�� */

//PWM1:PD15,TIM4_CH4
#define PWM1_IO_CLK     RCC_AHB1Periph_GPIOD
#define PWM1_IO_PORT    GPIOD
#define PWM1_IO_PIN     GPIO_Pin_15
#define PWM1_IO_AF      GPIO_AF_TIM4
#define PWM1_PINSOURCE  GPIO_PinSource15
#define PWM1_TIMER      TIM4
#define PWM1_TIMER_CLK  RCC_APB1Periph_TIM4
#define PWM1_TIMER_CLK_CMD  RCC_APB1PeriphClockCmd
#define PWM1_PWMINIT    TIM_OC4Init
#define PWM1_DUTYCFG    TIM_SetCompare4
#define PWM1_DUTYGET    TIM_GetCapture4
//#define PWM1_TIMER_IRQn TIM4_IRQn
//#define PWM1_TIMER_ISR  TIM4_IRQHandler

//PWM2:PB0,TIM3_CH3
#define PWM2_IO_CLK     RCC_AHB1Periph_GPIOB
#define PWM2_IO_PORT    GPIOB
#define PWM2_IO_PIN     GPIO_Pin_0
#define PWM2_IO_AF      GPIO_AF_TIM3
#define PWM2_PINSOURCE  GPIO_PinSource0
#define PWM2_TIMER      TIM3
#define PWM2_TIMER_CLK  RCC_APB1Periph_TIM3
#define PWM2_TIMER_CLK_CMD  RCC_APB1PeriphClockCmd
#define PWM2_PWMINIT    TIM_OC3Init
#define PWM2_DUTYCFG    TIM_SetCompare3
#define PWM2_DUTYGET    TIM_GetCapture3
//#define PWM2_TIMER_IRQn TIM3_IRQn
//#define PWM2_TIMER_ISR  TIM3_IRQHandler

//�ж�PWM��ʱ����APBʱ��Ƶ�ʣ�Hz��
#if PWM1_TIMER_CLK_CMD==RCC_APB1PeriphClockCmd
  #define PWM1_APB_CLK  84000000
#else
  #define PWM1_APB_CLK 168000000
#endif
#if PWM2_TIMER_CLK_CMD==RCC_APB1PeriphClockCmd
  #define PWM2_APB_CLK  84000000
#else
  #define PWM2_APB_CLK 168000000
#endif

void pwm_cmd(e_pwm ch, FunctionalState NewState);
uint8_t pwm_duty(e_pwm ch, uint8_t duty);
void pwm_Init(void);

#endif
