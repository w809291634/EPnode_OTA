#include "pwm.h"

/* PWMͨ��ʹ�ܿ��� */
void pwm_cmd(e_pwm ch, FunctionalState NewState) {
  if(ch == PWM1) {
    TIM_Cmd(PWM1_TIMER, NewState);
  } else if(ch == PWM2) {
    TIM_Cmd(PWM2_TIMER, NewState);
  }
}

/* PWMͨ��ռ�ձ����ã�duty��0-100��duty==0xFFʱ�����ص�ǰռ�ձ� */
uint8_t pwm_duty(e_pwm ch, uint8_t duty) {
  if(duty==0xFF) {
    if(ch == PWM1) return PWM1_DUTYGET(PWM1_TIMER);
    else if(ch == PWM2) return PWM2_DUTYGET(PWM2_TIMER);
  } else if(duty > 100) {
    duty = 100;
  }
  if(ch == PWM1) {
    PWM1_DUTYCFG(PWM1_TIMER, duty);
  } else if(ch == PWM2) {
    PWM2_DUTYCFG(PWM2_TIMER, duty);
  }
  return duty;
}

void pwm_Init(void) {
  //GPIO��ʼ��
  GPIO_InitTypeDef GPIO_InitStruct;
  RCC_AHB1PeriphClockCmd(PWM1_IO_CLK | PWM2_IO_CLK, ENABLE);
  GPIO_PinAFConfig(PWM1_IO_PORT, PWM1_PINSOURCE, PWM1_IO_AF);
  GPIO_PinAFConfig(PWM2_IO_PORT, PWM2_PINSOURCE, PWM2_IO_AF);
  GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL;
  GPIO_InitStruct.GPIO_Pin = PWM1_IO_PIN;
  GPIO_Init(PWM1_IO_PORT, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = PWM2_IO_PIN;
  GPIO_Init(PWM2_IO_PORT, &GPIO_InitStruct);
  
  //��ʱ��ʱ����ʼ��
  TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
  //APB1:42MHz--TIM2/3/4/5/6/7/12/13/14:84MHz; APB2:84MHz--TIM1/8/9/10/11:168MHz
  PWM1_TIMER_CLK_CMD(PWM1_TIMER_CLK, ENABLE);
  PWM2_TIMER_CLK_CMD(PWM2_TIMER_CLK, ENABLE);
  TIM_TimeBaseInitStruct.TIM_Period = 100-1;//ռ�ձȷֱ��ʣ�0-100%
  TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInitStruct.TIM_Prescaler = PWM1_APB_CLK/PWM1_FREQ/100-1;//PWMƵ�ʣ���ƵƵ��/100
  TIM_TimeBaseInit(PWM1_TIMER, &TIM_TimeBaseInitStruct);
  TIM_TimeBaseInitStruct.TIM_Prescaler = PWM2_APB_CLK/PWM2_FREQ/100-1;
  TIM_TimeBaseInit(PWM2_TIMER, &TIM_TimeBaseInitStruct);
  
  //PWM��ʼ��
  TIM_OCInitTypeDef TIM_OCInitStruct;
  TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStruct.TIM_OutputNState = TIM_OutputNState_Disable;
  TIM_OCInitStruct.TIM_Pulse = 50;
  TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_Low;
  TIM_OCInitStruct.TIM_OCIdleState = TIM_OCIdleState_Set;
  PWM1_PWMINIT(PWM1_TIMER, &TIM_OCInitStruct);
  PWM2_PWMINIT(PWM2_TIMER, &TIM_OCInitStruct);
  
  pwm_cmd(PWM1, ENABLE);
  pwm_cmd(PWM2, DISABLE);
}
