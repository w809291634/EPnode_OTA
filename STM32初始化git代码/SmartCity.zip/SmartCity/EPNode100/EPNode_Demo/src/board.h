#ifndef __BOARD_H_
#define __BOARD_H_
#include "stm32f4xx.h"
#include <rtthread.h>

// APP����ַ:0x08010000
#define USER_APP_BEGIN ((uint32_t)0x08010000)

void rt_hw_udelay(rt_uint32_t us);


#endif
