#ifndef _FINSH_EX_H_
#define _FINSH_EX_H_

#include "bsp_flash/flash.h"

#define BOOT_IAP    0xA2
#define BOOT_REC    0x2B
#define BOOT_APP    0x3C

#define APP_OK      0x4D
#define APP_ERR     0xFF

#define REC_DONE    0x2E
#define REC_NULL    0xFF

typedef struct {
  unsigned char boot_mode;
  unsigned char app_en;
  unsigned char rec_sta;
  unsigned char reserved;
} t_sys_param;

extern uint8_t sys_param[];

#endif