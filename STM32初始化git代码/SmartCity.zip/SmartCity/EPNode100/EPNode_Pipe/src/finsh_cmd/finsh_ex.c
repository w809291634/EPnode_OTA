#include <rtthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "finsh_ex.h"
#include "apl_flash/saveData_manage.h"

#define DEBUG_EN
#define RF_EN
#define SENSOR_EN
//#define PWM_EN
#define IAP_EN
#define REBOOT_EN

#ifdef DEBUG_EN
uint8_t debug_flag = 0;
int debug(int argc, char **argv) {
  if(argc == 2) {
    if(!rt_strcmp(argv[1], "on")) {
      debug_flag = 1;
      rt_kprintf("Debug info on\n");
    } else if(!rt_strcmp(argv[1], "off")) {
      debug_flag = 0;
      rt_kprintf("Debug info off\n");
    }
  }
  return 0;
}
MSH_CMD_EXPORT(debug, System debug infomation set.);
#endif  //DEBUG_EN

#ifdef RF_EN
#include "rf_thread.h"
#if RF_SELECT==RF_IF1
#include "rf_if1_app.h"
#include "rf_if1_hw.h"
#include "zigbee/zigbee_drv.h"
#include "lora/lora_drv.h"
#include "nb-iot/nb_drv.h"
#include "cat1/cat1_drv.h"
static void zigbee_ctrl(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("Zigbee info:\n");
    rt_kprintf("\tMAC: %s\n", zigbee_info.mac);
    rt_kprintf("\tPANID: %u\n", zigbee_info.panid);
    rt_kprintf("\tChannel: %u\n", zigbee_info.channel);
    rt_kprintf("\tType: %u\n", zigbee_info.type);
  } else if(argc == 3) {
    uint32_t value = strtol(argv[2], NULL, 0);
    if(!rt_strcmp(argv[1], "panid")) {
      if(zigbee_Set_Panid(value) == 0) {
        rt_kprintf("Zigbee panid set: %u\n", zigbee_info.panid);
      } else {
        rt_kprintf("Zigbee panid set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "channel")) {
      if(zigbee_Set_Channel(value) == 0) {
        rt_kprintf("Zigbee channel set: %u\n", zigbee_info.channel);
      } else {
        rt_kprintf("Zigbee channel set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "type")) {
      if(zigbee_Set_Type(value) == 0) {
        rt_kprintf("Zigbee type set: %u\n", zigbee_info.type);
      } else {
        rt_kprintf("Zigbee type set failed!\n");
      }
    }
  }
}

static void lora_ctrl(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("LoRa info:\n");
    rt_kprintf("\tNode ID: %u\n", lora_info.node_id);
    rt_kprintf("\tNet ID: %u\n", lora_info.net_id);
    rt_kprintf("\tFP: %u\n", lora_info.fp);
    rt_kprintf("\tPV: %u\n", lora_info.pv);
    rt_kprintf("\tSF: %u\n", lora_info.sf);
    rt_kprintf("\tCR: %u\n", lora_info.cr);
    rt_kprintf("\tPS: %u\n", lora_info.ps);
    rt_kprintf("\tBW: %u\n", lora_info.bw);
    rt_kprintf("\tHOP: %u\n", lora_info.hop);
    rt_kprintf("\tHOP Tab: %s\n", lora_info.hopTab);
  } else if(argc == 3) {
    uint32_t value = strtol(argv[2], NULL, 0);
    if(!rt_strcmp(argv[1], "netid")) {
      if(lora_set_handle(1, value) == 0) {
        rt_kprintf("LoRa netid set: %u\n", lora_info.net_id);
      } else {
        rt_kprintf("LoRa netid set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "fp")) {
      if(lora_set_handle(2, value) == 0) {
        rt_kprintf("LoRa fp set: %u\n", lora_info.fp);
      } else {
        rt_kprintf("LoRa fp set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "pv")) {
      if(lora_set_handle(3, value) == 0) {
        rt_kprintf("LoRa pv set: %u\n", lora_info.pv);
      } else {
        rt_kprintf("LoRa pv set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "sf")) {
      if(lora_set_handle(4, value) == 0) {
        rt_kprintf("LoRa sf set: %u\n", lora_info.sf);
      } else {
        rt_kprintf("LoRa sf set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "cr")) {
      if(lora_set_handle(5, value) == 0) {
        rt_kprintf("LoRa cr set: %u\n", lora_info.cr);
      } else {
        rt_kprintf("LoRa cr set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "ps")) {
      if(lora_set_handle(6, value) == 0) {
        rt_kprintf("LoRa ps set: %u\n", lora_info.ps);
      } else {
        rt_kprintf("LoRa ps set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "bw")) {
      if(lora_set_handle(7, value) == 0) {
        rt_kprintf("LoRa bw set: %u\n", lora_info.bw);
      } else {
        rt_kprintf("LoRa bw set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "hop")) {
      if(lora_set_handle(8, value) == 0) {
        rt_kprintf("LoRa hop set: %u\n", lora_info.hop);
      } else {
        rt_kprintf("LoRa hop set failed!\n");
      }
    }
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "save")) {
      if(lora_set_handle(9, 0) == 0) {
        rt_kprintf("LoRa config save successed!\n");
      } else {
        rt_kprintf("LoRa config save failed!\n");
      }
    }
  }
}

static void nb_ctrl(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("NB-IoT info:\n");
    rt_kprintf("\tNode ID: %s\n", nb_info.node_id);
    rt_kprintf("\tMode: %s\n", nb_info.mode);
    rt_kprintf("\tSIP: %s\n", nb_info.sip);
    rt_kprintf("\tAID: %s\n", nb_info.aid);
    rt_kprintf("\tAKey: %s\n", nb_info.akey);
  } else if(argc == 3) {
    if(!rt_strcmp(argv[1], "mode")) {
      if(nb_set_handle(1, argv[2]) == 0) {
        rt_kprintf("NB-IoT mode set: %s\n", nb_info.mode);
      } else {
        rt_kprintf("NB-IoT mode set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "sip")) {
      if(nb_set_handle(2, argv[2]) == 0) {
        rt_kprintf("NB-IoT sip set: %s\n", nb_info.sip);
      } else {
        rt_kprintf("NB-IoT sip set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "aid")) {
      if(nb_set_handle(3, argv[2]) == 0) {
        rt_kprintf("NB-IoT aid set: %s\n", nb_info.aid);
      } else {
        rt_kprintf("NB-IoT aid set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "akey")) {
      if(nb_set_handle(4, argv[2]) == 0) {
        rt_kprintf("NB-IoT akey set: %s\n", nb_info.akey);
      } else {
        rt_kprintf("NB-IoT akey set failed!\n");
      }
    }
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "save")) {
      if(nb_set_handle(5, 0) == 0) {
        rt_kprintf("NB-IoT config save successed!\n");
      } else {
        rt_kprintf("NB-IoT config save failed!\n");
      }
    }
  }
}

static void cat1_ctrl(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("CAT1 info:\n");
    rt_kprintf("\tNode ID: %s\n", cat1_info.node_id);
    rt_kprintf("\tSIP: %s\n", cat1_info.sip);
    rt_kprintf("\tAID: %s\n", cat1_info.aid);
    rt_kprintf("\tAKey: %s\n", cat1_info.akey);
  } else if(argc == 3) {
    if(!rt_strcmp(argv[1], "sip")) {
      if(nb_set_handle(2, argv[2]) == 0) {
        rt_kprintf("CAT1 sip set: %s\n", nb_info.sip);
      } else {
        rt_kprintf("CAT1 sip set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "aid")) {
      if(nb_set_handle(3, argv[2]) == 0) {
        rt_kprintf("CAT1 aid set: %s\n", nb_info.aid);
      } else {
        rt_kprintf("CAT1 aid set failed!\n");
      }
    } else if(!rt_strcmp(argv[1], "akey")) {
      if(nb_set_handle(4, argv[2]) == 0) {
        rt_kprintf("CAT1 akey set: %s\n", nb_info.akey);
      } else {
        rt_kprintf("CAT1 akey set failed!\n");
      }
    }
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "save")) {
      if(nb_set_handle(5, 0) == 0) {
        rt_kprintf("CAT1 config save successed!\n");
      } else {
        rt_kprintf("CAT1 config save failed!\n");
      }
    }
  }
}

#elif RF_SELECT==RF_IF2
#include "rf_if2_app.h"
#include "rf_if2_hw.h"
static void ec20_ctrl(int argc, char **argv) {
  extern t_rf_zhiyun rf_zhiyun_cfg;      //��������
  if(argc == 1) {
    rt_kprintf("EC20 info:\n");
    rt_kprintf("\tNode ID: %s\n", rf_if2_imei);
    rt_kprintf("\tAID: %s\n", rf_zhiyun_cfg.zhiyun_id);
    rt_kprintf("\tAKey: %s\n", rf_zhiyun_cfg.zhiyun_key);
  } else if(argc == 3) {
    if(!rt_strcmp(argv[1], "aid")) {
      strcpy(rf_zhiyun_cfg.zhiyun_id, argv[2]);
      rt_kprintf("EC20 aid set: %s\n", rf_zhiyun_cfg.zhiyun_id);
    } else if(!rt_strcmp(argv[1], "akey")) {
      strcpy(rf_zhiyun_cfg.zhiyun_key, argv[2]);
      rt_kprintf("EC20 akey set: %s\n", rf_zhiyun_cfg.zhiyun_key);
    }
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "save")) {
      saveData_Update();
      rt_kprintf("EC20 config save successed!\n");
    }
  }
}
#endif

int rf(int argc, char **argv) {
  extern uint8_t rf_Link_On;
#if RF_SELECT==RF_IF1
  char rf1_device[5][10] = {"NULL", "ZIGBEE", "LORA", "NB-IoT", "CAT1"};
  if(argc == 1) {
    rt_kprintf("RF interface1 device: %s\n", rf1_device[rf_if1_dev]);
    rt_kprintf("RF Link: %s\n", rf_Link_On==1 ? "ON" : "OFF");
    rt_kprintf("RF RSSI: %d\n", rf_if1_get_rssi());
  } else if(argc == 3 && !rt_strcmp(argv[1], "trans")) {    //͸������
    rf_if1_uart_send((uint8_t*)argv[2], strlen(argv[2]));
    rf_if1_uart_send((uint8_t*)"\r\n", strlen("\r\n"));
  }
  //���豸���н�һ������
  switch(rf_if1_dev) {
    case RF_IF1_ZIGBEE:
      zigbee_ctrl(argc, argv);
    break;
    case RF_IF1_LORA:
      lora_ctrl(argc, argv);
    break;
    case RF_IF1_NB:
      nb_ctrl(argc, argv);
    break;
    case RF_IF1_CAT1:
      cat1_ctrl(argc, argv);
    break;
    default: break;
  }
#elif RF_SELECT==RF_IF2
  char rf2_device[3][10] = {"NULL", "EC20"};
  extern int ec20_rssi;
  if(argc == 1) {
    rt_kprintf("RF interface2 device: %s\n", rf2_device[rf_if2_dev]);
    rt_kprintf("RF Link: %s\n", rf_Link_On==1 ? "ON" : "OFF");
    rt_kprintf("RF RSSI: %d\n", ec20_rssi);
  } else if(argc == 3 && !rt_strcmp(argv[1], "trans")) {    //͸������
    rf_if2_uart_send((uint8_t*)argv[2], strlen(argv[2]));
  }
  //���豸���н�һ������
  switch(rf_if2_dev) {
    case RF_IF2_LTE:
      ec20_ctrl(argc, argv);
    break;
    default: break;
  }
#endif
  return 0;
}
MSH_CMD_EXPORT(rf, RF Device Control.);
#endif

#ifdef SENSOR_EN
#include "sensor/sensor.h"
#if RF_SELECT==RF_IF1
  #include "rf_if1_hw.h"
  #define RF_DATA_MB    rf_if1_data_mb
#elif RF_SELECT==RF_IF2
  #include "rf_if2_hw.h"
  #define RF_DATA_MB    rf_if2_data_mb
#endif
char finsh_zxbee_recv_data[101];
int sensor(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("Version: %s\n", FIRMWARE_VER);
    rt_kprintf("Sensor type: %u\n", SENSOR_TYPE);
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "check")) {
      sensor_cali(5, 0);
    } else if(!rt_strcmp(argv[1], "clear")) {
      saveData_Clear();
      NVIC_SystemReset();
      while(1);
    } else {
      strncpy(finsh_zxbee_recv_data, argv[1], 100);
      finsh_zxbee_recv_data[100] = 0;
      rt_mb_send(&RF_DATA_MB, 2);//�ʼ����ݣ�2--��Wifi����̨�������ʼ�
    }
  } else if(argc == 4) {
    if(!rt_strcmp(argv[1], "check")) {
      int ch = strtol(argv[2], NULL, 0);
      int value = strtol(argv[3], NULL, 0);
      sensor_cali(ch, value);
    }
  }
  return 0;
}
MSH_CMD_EXPORT(sensor, Sensor Handle.);
#endif

#ifdef PWM_EN
#include "bsp_pwm/pwm.h"
int pwm(int argc, char **argv) {
  if(argc == 1) {
    rt_kprintf("\tPWM1 duty: %d\n", pwm_duty(PWM1, 0xFF));
    rt_kprintf("\tPWM2 duty: %d\n", pwm_duty(PWM2, 0xFF));
  } else if(argc == 3) {
    uint32_t ch = strtol(argv[1], NULL, 0);
    uint32_t duty = strtol(argv[2], NULL, 0);
    if(ch == 0 || ch > 2) {
      rt_kprintf("Error! Channel must be 1-2!\n");
      return 0;
    }
    duty = duty>100 ? 100 : duty;
    rt_kprintf("PWM%d duty set to %d.\n", ch, pwm_duty((e_pwm)ch, duty));
  }
  return 0;
}
MSH_CMD_EXPORT(pwm, PWM output config.);
#endif

#ifdef IAP_EN
#define BUF_LEN 1024
static void rf_iap_thread_entry(void *parameter) {
  static uint8_t  rf_buf[BUF_LEN], debug_buf[BUF_LEN];
  uint16_t rf_index_in = 0, rf_index_out = 0, debug_index_in = 0, debug_index_out = 0;
  uint32_t mb_recv;
  char recv[101];
  rf_if1_uart_send((uint8_t*)"AT+IAP=IAP\r\n", strlen("AT+IAP=IAP\r\n"));
  rt_err_t err = rt_mb_recv(&rf_if1_data_mb, (rt_ubase_t*)&mb_recv, RT_WAITING_FOREVER);
  if(err == RT_EOK) {
    uint16_t len = rf_if1_uart_read((uint8_t *)recv, 50, 100);
    if(len>0) {
      recv[len] = 0;
      if(strstr((const char*)recv, "OK") != NULL) {
        /*****************����RF�̼�����ģʽ*******************/
        rt_kprintf("-_-");
        rt_thread_mdelay(100);
        //�޸�RF���ں͵��Դ��ڹ���ģʽ���ر��жϣ�ͨ��DMA�����ݴ��뻺����
        DMA_InitTypeDef DMA_InitStruct;
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);

        DMA_DeInit(RF_IF1_DMA_STREAM);
        DMA_DeInit(DMA2_Stream1);
        DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralToMemory;
        DMA_InitStruct.DMA_BufferSize = BUF_LEN;
        DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
        DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;
        DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
        DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
        DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;
        DMA_InitStruct.DMA_Priority = DMA_Priority_High;
        DMA_InitStruct.DMA_FIFOMode = DMA_FIFOMode_Disable;      
        DMA_InitStruct.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
        DMA_InitStruct.DMA_MemoryBurst = DMA_MemoryBurst_Single;
        DMA_InitStruct.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
        
        DMA_InitStruct.DMA_Channel = RF_IF1_DMA_CHANNEL;
        DMA_InitStruct.DMA_Memory0BaseAddr = (uint32_t)(&rf_buf[0]);
        DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)&(RF_IF1_UART->DR);
        DMA_Init(RF_IF1_DMA_STREAM, &DMA_InitStruct);
        DMA_InitStruct.DMA_Channel = DMA_Channel_5;
        DMA_InitStruct.DMA_Memory0BaseAddr = (uint32_t)(&debug_buf[0]);
        DMA_InitStruct.DMA_PeripheralBaseAddr = (uint32_t)&(USART6->DR);
        DMA_Init(DMA2_Stream1, &DMA_InitStruct);
        DMA_Cmd(RF_IF1_DMA_STREAM, ENABLE);
        DMA_Cmd(DMA2_Stream1, ENABLE);
        
        USART_InitTypeDef USART_InitStructure;
        USART_DeInit(RF_IF1_UART);
        USART_DeInit(USART6);
        USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
        USART_InitStructure.USART_StopBits            = USART_StopBits_1;
        USART_InitStructure.USART_Parity              = USART_Parity_No ;
        USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
        USART_InitStructure.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
        
        USART_InitStructure.USART_BaudRate            = 38400;
        USART_Init(RF_IF1_UART, &USART_InitStructure);
        USART_InitStructure.USART_BaudRate            = 115200;
        USART_Init(USART6, &USART_InitStructure);
        
        USART_ClearFlag(RF_IF1_UART, USART_FLAG_RXNE);
        USART_ClearFlag(USART6, USART_FLAG_RXNE);
        USART_DMACmd(RF_IF1_UART, USART_DMAReq_Rx, ENABLE);
        USART_DMACmd(USART6, USART_DMAReq_Rx, ENABLE);
        USART_Cmd(RF_IF1_UART, ENABLE);
        USART_Cmd(USART6, ENABLE);
        
        while(1) {
          rf_index_in = (BUF_LEN - DMA_GetCurrDataCounter(RF_IF1_DMA_STREAM))%BUF_LEN;
          debug_index_in = (BUF_LEN - DMA_GetCurrDataCounter(DMA2_Stream1))%BUF_LEN;
          //�յ��µ�ͨѶ��������ʱ�������ݷ��͸����Դ���
          while(rf_index_out != rf_index_in) {
            USART_SendData(USART6, rf_buf[rf_index_out]);
            while(USART_GetFlagStatus(USART6, USART_FLAG_TXE) == RESET);
            rf_index_out = (rf_index_out+1)%BUF_LEN;
          }
          //�յ��µĵ��Դ�������ʱ�������ݷ��͸�ͨѶ����
          while(debug_index_out != debug_index_in) {
            USART_SendData(RF_IF1_UART, debug_buf[debug_index_out]);
            while(USART_GetFlagStatus(RF_IF1_UART, USART_FLAG_TXE) == RESET);
            debug_index_out = (debug_index_out+1)%BUF_LEN;
          }
        }
      }
    }
  }
  rt_kprintf("\nError: RF module doesn't support IAP mode!\n");
}

uint8_t sys_param[sizeof(t_sys_param)];
int IAP(int argc, char **argv) {
  t_sys_param *p_param = (t_sys_param *)sys_param;
  char mode[4][10] = {"IAP", "Recovery", "APP", "Error"};
  if(argc == 1) {
    uint8_t mode_index;
    switch(p_param->boot_mode) {
      case BOOT_IAP: mode_index = 0; break;
      case BOOT_REC: mode_index = 1; break;
      case BOOT_APP: mode_index = 2; break;
      default: mode_index = 3;
    }
    rt_kprintf("IAP mode:\t%s\n", mode[mode_index]);
    rt_kprintf("REC status:\t%s\n", p_param->rec_sta==REC_DONE ? "Done" : "Null");
    rt_kprintf("Optional parameters:\n");
    rt_kprintf("\tupdate:\tTo update APP firmware.\n");
    rt_kprintf("\tapp:\tTo fix APP mode.\n");
  } else if(argc == 2) {
    if(!rt_strcmp(argv[1], "update")) { //�л���IAPģʽ(���¹̼�)
      if(p_param->boot_mode != BOOT_IAP) {
        //�޸Ĳ���
        p_param->boot_mode = BOOT_IAP;
        //�������
        flash_write(FLASH_PARAM_START_ADDR, (unsigned char *)(sys_param), sizeof(t_sys_param));
      }
      //ϵͳ����
      NVIC_SystemReset();
    } else if(!rt_strcmp(argv[1], "app")) { //�̶�ΪAPPģʽ
      if(p_param->boot_mode != BOOT_APP) {
        //�޸Ĳ���
        p_param->boot_mode = BOOT_APP;
        //�������
        flash_write(FLASH_PARAM_START_ADDR, (unsigned char *)(sys_param), sizeof(t_sys_param));
      }
      rt_kprintf("APP Mode Fixed\n");
    } else if(!rt_strcmp(argv[1], "rf")) { //����RF�̼�����ģʽ��ΪͨѶģ����¹̼�
      rt_thread_t rf_iap_thread = rt_thread_create("rf_iap", rf_iap_thread_entry, RT_NULL, 1024, 0, 20);
      rt_thread_startup(rf_iap_thread);
    }
  }
  return 0;
}
MSH_CMD_EXPORT(IAP, System firmware Manage.);
#endif

#ifdef REBOOT_EN
int reboot(int argc, char **argv) {
  //ϵͳ����
  NVIC_SystemReset();
  while(1);
}
MSH_CMD_EXPORT(reboot, System Reboot.);
#endif
