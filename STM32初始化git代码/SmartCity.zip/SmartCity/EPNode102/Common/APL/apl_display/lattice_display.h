#ifndef _LATTICE_DISPLAY_H_
#define _LATTICE_DISPLAY_H_

#include "drv_lattice/lattice.h"

typedef enum {
  Traffic_Null=0, Traffic_Circle, Traffic_Ahead, Traffic_Left, Traffic_Right
} e_Traffic_Shape;

void traffice_display(e_Lattice lattice, e_Traffic_Shape shape);
void number_display(e_Lattice lattice, uint8_t num);

#endif  //_LATTICE_DISPLAY_H_
