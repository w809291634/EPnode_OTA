#include "relay.h"

void relay_Init(void) {
  GPIO_InitTypeDef GPIO_InitStruct;
  RCC_AHB1PeriphClockCmd(RELAY_CH1_CLK | RELAY_CH2_CLK | RELAY_CH3_CLK | RELAY_CH4_CLK, ENABLE);
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Low_Speed;
  
  GPIO_InitStruct.GPIO_Pin = RELAY_CH1_PIN;
  GPIO_Init(RELAY_CH1_GPIO, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = RELAY_CH2_PIN;
  GPIO_Init(RELAY_CH2_GPIO, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = RELAY_CH3_PIN;
  GPIO_Init(RELAY_CH2_GPIO, &GPIO_InitStruct);
  GPIO_InitStruct.GPIO_Pin = RELAY_CH4_PIN;
  GPIO_Init(RELAY_CH2_GPIO, &GPIO_InitStruct);
  relay_off(1);
  relay_off(2);
  relay_off(3);
  relay_off(4);
}

void relay_on(uint8_t ch) {
  switch(ch) {
    case 1: GPIO_SetBits(RELAY_CH1_GPIO, RELAY_CH1_PIN); break;
    case 2: GPIO_SetBits(RELAY_CH2_GPIO, RELAY_CH2_PIN); break;
    case 3: GPIO_SetBits(RELAY_CH3_GPIO, RELAY_CH3_PIN); break;
    case 4: GPIO_SetBits(RELAY_CH4_GPIO, RELAY_CH4_PIN); break;
  }
}

void relay_off(uint8_t ch) {
  switch(ch) {
    case 1: GPIO_ResetBits(RELAY_CH1_GPIO, RELAY_CH1_PIN); break;
    case 2: GPIO_ResetBits(RELAY_CH2_GPIO, RELAY_CH2_PIN); break;
    case 3: GPIO_ResetBits(RELAY_CH3_GPIO, RELAY_CH3_PIN); break;
    case 4: GPIO_ResetBits(RELAY_CH4_GPIO, RELAY_CH4_PIN); break;
  }
}

void relay_toggle(uint8_t ch) {
  switch(ch) {
    case 1: GPIO_ToggleBits(RELAY_CH1_GPIO, RELAY_CH1_PIN); break;
    case 2: GPIO_ToggleBits(RELAY_CH2_GPIO, RELAY_CH2_PIN); break;
    case 3: GPIO_ToggleBits(RELAY_CH3_GPIO, RELAY_CH3_PIN); break;
    case 4: GPIO_ToggleBits(RELAY_CH4_GPIO, RELAY_CH4_PIN); break;
  }
}
