#ifndef _LATTICE_H_
#define _LATTICE_H_

#include "stm32f4xx.h"

#define LAT_CHIP_BASE_ID    0x70    /* ��������оƬI2C��ַ��ַ��ÿ������4��оƬ����ַλ0x70-0x73 */

typedef enum {
  LAT1=0x01, LAT2=0x02, LAT3=0x04, LAT4=0x08, LAT_ALL=0x0F
} e_Lattice;

typedef enum {
  LAT_HANDLE_INIT=0xF0, LAT_HANDLE_READ, LAT_HANDLE_WRITE
} e_Lat_Handle;

typedef enum {
  LAT_Green=0xE0, LAT_Red, LAT_Yellow
} e_Lat_Color;

void lattice_fill(e_Lattice lattice, uint8_t data, e_Lat_Color color);
void lattice_clear(e_Lattice lattice);
void lattice_display(e_Lattice lattice, uint8_t show[32], e_Lat_Color color);
void lattice_Init(e_Lattice lattice);

#endif