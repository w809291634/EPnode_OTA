#ifndef _I2C_H_
#define _I2C_H_

#include "stm32f4xx.h"

typedef enum IO_Status {
  I2C_INPUT=0, I2C_OUTPUT
} e_IO_Stataus;

typedef struct I2C_RW_INFO {
  uint16_t device_id; //�豸��ַ��7λ��ַʱ���������շ�λ
  uint8_t  id_length; //��ַ���ȣ�7��10��
  uint8_t  wait_en;   //�����Ĵ������Ƿ�ȴ�������ɣ�0:���ȴ���1:�ȴ���
  uint8_t  reg_en;    //�Ƿ���Ҫд��Ĵ�����ַ��0:����Ҫ��1:��Ҫ��
  uint8_t  reg_addr;  //�Ĵ�����ַ
  uint16_t data_len;  //���ݳ���
  uint8_t  *reg_data; //�Ĵ�������ָ��
} t_I2C_RW_INFO;

/**********************************I2C1���**********************************/
#define I2C1_SCL_PIN        GPIO_Pin_8
#define I2C1_SCL_PORT       GPIOB
#define I2C1_SCL_CLK        RCC_AHB1Periph_GPIOB

#define I2C1_SDA_PIN        GPIO_Pin_9
#define I2C1_SDA_PORT       GPIOB
#define I2C1_SDA_CLK        RCC_AHB1Periph_GPIOB

#define I2C1_SCL_H()        (GPIO_SetBits(I2C1_SCL_PORT, I2C1_SCL_PIN))
#define I2C1_SCL_L()        (GPIO_ResetBits(I2C1_SCL_PORT, I2C1_SCL_PIN))
#define I2C1_SDA_H()        (GPIO_SetBits(I2C1_SDA_PORT, I2C1_SDA_PIN))
#define I2C1_SDA_L()        (GPIO_ResetBits(I2C1_SDA_PORT, I2C1_SDA_PIN))

#define I2C1_SCL_STATUS()   (GPIO_ReadInputDataBit(I2C1_SCL_PORT, I2C1_SCL_PIN))
#define I2C1_SDA_STATUS()   (GPIO_ReadInputDataBit(I2C1_SDA_PORT, I2C1_SDA_PIN))

void i2c1_Init(void);
void i2c1_Write_Reg(t_I2C_RW_INFO *prw_info);
void i2c1_Read_Reg(t_I2C_RW_INFO *prw_info);

/**********************************I2C2���**********************************/
#define I2C2_SCL_PIN        GPIO_Pin_3
#define I2C2_SCL_PORT       GPIOE
#define I2C2_SCL_CLK        RCC_AHB1Periph_GPIOE

#define I2C2_SDA_PIN        GPIO_Pin_4
#define I2C2_SDA_PORT       GPIOE
#define I2C2_SDA_CLK        RCC_AHB1Periph_GPIOE

#define I2C2_SCL_H()        (GPIO_SetBits(I2C2_SCL_PORT, I2C2_SCL_PIN))
#define I2C2_SCL_L()        (GPIO_ResetBits(I2C2_SCL_PORT, I2C2_SCL_PIN))
#define I2C2_SDA_H()        (GPIO_SetBits(I2C2_SDA_PORT, I2C2_SDA_PIN))
#define I2C2_SDA_L()        (GPIO_ResetBits(I2C2_SDA_PORT, I2C2_SDA_PIN))

#define I2C2_SCL_STATUS()   (GPIO_ReadInputDataBit(I2C2_SCL_PORT, I2C2_SCL_PIN))
#define I2C2_SDA_STATUS()   (GPIO_ReadInputDataBit(I2C2_SDA_PORT, I2C2_SDA_PIN))

void i2c2_Init(void);
void i2c2_Write_Reg(t_I2C_RW_INFO *prw_info);
void i2c2_Read_Reg(t_I2C_RW_INFO *prw_info);

/**********************************I2C3���**********************************/
#define I2C3_SCL_PIN        GPIO_Pin_8
#define I2C3_SCL_PORT       GPIOA
#define I2C3_SCL_CLK        RCC_AHB1Periph_GPIOA

#define I2C3_SDA_PIN        GPIO_Pin_9
#define I2C3_SDA_PORT       GPIOC
#define I2C3_SDA_CLK        RCC_AHB1Periph_GPIOC

#define I2C3_SCL_H()        (GPIO_SetBits(I2C3_SCL_PORT, I2C3_SCL_PIN))
#define I2C3_SCL_L()        (GPIO_ResetBits(I2C3_SCL_PORT, I2C3_SCL_PIN))
#define I2C3_SDA_H()        (GPIO_SetBits(I2C3_SDA_PORT, I2C3_SDA_PIN))
#define I2C3_SDA_L()        (GPIO_ResetBits(I2C3_SDA_PORT, I2C3_SDA_PIN))

#define I2C3_SCL_STATUS()   (GPIO_ReadInputDataBit(I2C3_SCL_PORT, I2C3_SCL_PIN))
#define I2C3_SDA_STATUS()   (GPIO_ReadInputDataBit(I2C3_SDA_PORT, I2C3_SDA_PIN))

void i2c3_Init(void);
void i2c3_Write_Reg(t_I2C_RW_INFO *prw_info);
void i2c3_Read_Reg(t_I2C_RW_INFO *prw_info);

/**********************************I2C4���**********************************/
#define I2C4_SCL_PIN        GPIO_Pin_11
#define I2C4_SCL_PORT       GPIOD
#define I2C4_SCL_CLK        RCC_AHB1Periph_GPIOD

#define I2C4_SDA_PIN        GPIO_Pin_10
#define I2C4_SDA_PORT       GPIOD
#define I2C4_SDA_CLK        RCC_AHB1Periph_GPIOD

#define I2C4_SCL_H()        (GPIO_SetBits(I2C4_SCL_PORT, I2C4_SCL_PIN))
#define I2C4_SCL_L()        (GPIO_ResetBits(I2C4_SCL_PORT, I2C4_SCL_PIN))
#define I2C4_SDA_H()        (GPIO_SetBits(I2C4_SDA_PORT, I2C4_SDA_PIN))
#define I2C4_SDA_L()        (GPIO_ResetBits(I2C4_SDA_PORT, I2C4_SDA_PIN))

#define I2C4_SCL_STATUS()   (GPIO_ReadInputDataBit(I2C4_SCL_PORT, I2C4_SCL_PIN))
#define I2C4_SDA_STATUS()   (GPIO_ReadInputDataBit(I2C4_SDA_PORT, I2C4_SDA_PIN))

void i2c4_Init(void);
void i2c4_Write_Reg(t_I2C_RW_INFO *prw_info);
void i2c4_Read_Reg(t_I2C_RW_INFO *prw_info);

#endif //_I2C_H_
