#ifndef __APP_START_H__
#define __APP_START_H__
#include "iap_config.h"
#include "sys.h"

void jump_to_app(void);
void start_app_partition(uint8_t partition);
#endif
