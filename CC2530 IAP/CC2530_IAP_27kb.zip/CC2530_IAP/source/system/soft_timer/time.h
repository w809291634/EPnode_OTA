#ifndef _time_h_
#define _time_h_
#include "sys.h"

#define TICK_PER_SECOND 1000

void time1Int_init(u16 timeout);
#endif