#include "download.h"
#include "iap_config.h"
#include "ymodem.h"
#include "uart.h"
#include "hal_flash.h"
#include "flash.h"

extern uint8_t file_name[FILE_NAME_LENGTH];
uint8_t download_part;

// ͨ������ IAP �� flash ����һ���ļ�
void IAP_download(void)
{
  uint8_t Number[11] = "          ";
  int32_t Size = 0;
  uint32_t timeout=30*1000;
 
  /* ��������ģʽ */
  // ��������
  Size = Ymodem_Receive(APP1_PARTITION_START_ADDR,APP1_PARTITION_SIZE,timeout);
  hw_ms_delay(500);
  if (Size > 0)
  {
    printf("\n\n\r Programming Successfully!\n\r Name: %s",(char*)file_name);
    Int2Str(Number, Size);
    printf("\n\r Size: %s Bytes\r\n",(char*)Number);
    if(download_part==1) sys_parameter.app1_flag=APP_OK;
    write_sys_parameter();
  }
  /* �������̨ģʽ */
  usart0_mode=0;
}

