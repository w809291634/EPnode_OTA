#include "app_start.h"

void flash_jump_to_app()
{
  P0SEL = 0;
  U0CSR = 0;
  T2CTRL = 0;
  asm("LJMP 0xc000");  
//  HAL_SYSTEM_RESET();
  while(1){};
}

// ����appϵͳ����
void start_app_partition(uint8_t partition)
{
  switch(partition){
    case 1:{
      if(sys_parameter.app1_flag==APP_OK){
//        JumpToApp1(APP1_PARTITION_START_ADDR);
        flash_jump_to_app();
      }
    }break;
    case 0xff:break;
    default:{
      printf(INFO"partition %d not assigned!\r\n",partition);
    }break;
  }
}
