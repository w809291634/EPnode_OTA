#include "ZComDef.h"
#include "at.h"

int8 user_at_proc(char *msg)
{
  return -1;
}