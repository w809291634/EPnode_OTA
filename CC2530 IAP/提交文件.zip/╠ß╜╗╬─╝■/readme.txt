OtaConverter.exe oad.exe 放置
zstack-2.4.0-1.4.0x\Projects\zstack\Tools\CC2530DB

其他防止在sensor工程目录