#ifndef __USER_CMD_H__
#define __USER_CMD_H__
#include "sys.h"

#define  IAP_CMD                             "IAP"

void register_user_cmd(void);
#endif
