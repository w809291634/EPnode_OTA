#ifndef _PRINTK_H_
#define _PRINTK_H_

extern int printk(const char *fmt, ...);

#endif /* _VIVI_PRINTK_H_ */
